'use strict';
/* ================= Hilfsfunktionen ================= */
const $ = (s, el = document) => el.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const KANJI = '\\u3400-\\u4dbf\\u4e00-\\u9fff\\uf900-\\ufaff々〆ヶヵ';
const FURI_RE = new RegExp('([' + KANJI + ']+)\\[([^\\]]+)\\]', 'g');
const RE_K = new RegExp('[' + KANJI + ']');
const RE_KANA = /^[぀-ヿー・ 　〜~、。]+$/;
const RE_JP = /[぀-ヿ㐀-鿿]/;
const RE_LAT = /[A-Za-zÄÖÜäöüß]/;
const MIN = 60000, DAY = 86400000;
const LEARN_STEPS = [1, 10], RELEARN_STEPS = [10];
const shuffle = a => { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
const plain = s => String(s || '').replace(FURI_RE, '$1').replace(/ +/g, '');
const kana = s => String(s || '').replace(FURI_RE, '$2').replace(/\s+/g, '');
function jp(s) {
  let h = esc(s);
  h = h.replace(FURI_RE, (m, b, r) => S.settings.furigana ? '<ruby>' + b + '<rt>' + r + '</rt></ruby>' : b);
  return S.settings.spaces ? h.replace(/ +/g, '<span class="gap"></span>') : h.replace(/ +/g, '');
}
function dayStart(t = Date.now()) { const d = new Date(t - 4 * 3600000); d.setHours(0, 0, 0, 0); return d.getTime() + 4 * 3600000; }
function dayKey(t = Date.now()) { const d = new Date(t - 4 * 3600000); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
function jpDate(t = Date.now()) { const d = new Date(t); return (d.getMonth() + 1) + '月' + d.getDate() + '日（' + '日月火水木金土'[d.getDay()] + '）'; }
const ICON = {
  speaker: '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path d="M4 9v6h4l5 4V5L8 9H4z" fill="currentColor"/><path d="M16 8.5a4.5 4.5 0 0 1 0 7M18.6 6a8 8 0 0 1 0 12" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>',
  check: '<svg viewBox="0 0 24 24" width="14" height="14" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  stop: '<svg viewBox="0 0 24 24" width="14" height="14" aria-hidden="true"><rect x="6" y="6" width="12" height="12" rx="2" fill="currentColor"/></svg>',
  play: '<svg viewBox="0 0 24 24" width="14" height="14" aria-hidden="true"><path d="M7 5l12 7-12 7z" fill="currentColor"/></svg>'
};
function toast(msg) { const t = $('#toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.remove('show'), 2400); }

/* ================= Daten ================= */
const STARTER = STARTER_RAW.trim().split('\n').map((line, i) => { const [w, r, m, s, t] = line.split('|'); return { id: 'b' + i, w, r, m, s, t, p: '', g: Math.floor(i / 20) }; });
const DEFAULTS = { newPerDay: 10, cardMode: 'read', autoAudio: true, rate: 0.9, furigana: true, spaces: true, listenPool: 'known', hideInstall: false };
const S = { settings: { ...DEFAULTS }, log: {}, gdone: {}, tdone: {}, deckMeta: null, active: 'b', updatedAt: 0, srs: {}, deck: null };
const toRow = w => [w.w, w.r, w.m, w.s, w.t, w.p];
const rowsToDeck = rows => rows.map((r, i) => ({ id: 'i' + i, w: r[0] || '', r: r[1] || '', m: r[2] || '', s: r[3] || '', t: r[4] || '', p: r[5] || '' }));
const activeWords = () => (S.active === 'i' && S.deck) ? S.deck : STARTER;
const wordById = id => id[0] === 'b' ? STARTER[+id.slice(1)] : (S.deck ? S.deck[+id.slice(1)] : null);
const deckName = () => (S.active === 'i' && S.deckMeta) ? S.deckMeta.name : 'Starter-Deck';
function readingOf(w) { const r = w.r ? kana(w.r) : ''; return r && r !== plain(w.w) ? r : ''; }
function sayableWord(w) { const r = w.r ? kana(w.r).split(/[・、,;\/]/)[0] : ''; return r || kana(w.w) || plain(w.w); }
function todayLog() { const k = dayKey(); return S.log[k] || (S.log[k] = { n: 0, r: 0, c: 0, x: 0 }); }

/* ================= Plattform ================= */
const CAP = window.Capacitor || null;
const NATIVE = !!(CAP && CAP.isNativePlatform && CAP.isNativePlatform());
const PLATFORM = CAP && CAP.getPlatform ? CAP.getPlatform() : 'web';
const plugin = name => (NATIVE && CAP.registerPlugin) ? (CAP.Plugins[name] || CAP.registerPlugin(name)) : null;
const FS = plugin('Filesystem'), SHARE = plugin('Share'), APP = plugin('App'), NTTS = plugin('TextToSpeech');
const IS_IOS = /iPad|iPhone|iPod/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
const STANDALONE = (window.matchMedia && matchMedia('(display-mode: standalone)').matches) || navigator.standalone === true;

/* ================= Speicherung =================
   App (Android/iOS): JSON-Dateien im privaten App-Ordner. Web/PWA: localStorage. */
const Store = {
  async get(name) {
    if (FS) {
      try { const r = await FS.readFile({ path: 'manabu/' + name + '.json', directory: 'DATA', encoding: 'utf8' }); return JSON.parse(r.data); }
      catch (e) { return null; }
    }
    try { return JSON.parse(localStorage.getItem('manabu.' + name + '.v1')); } catch (e) { return null; }
  },
  async set(name, val) {
    const data = JSON.stringify(val);
    if (FS) {
      try { await FS.writeFile({ path: 'manabu/' + name + '.json', directory: 'DATA', encoding: 'utf8', data, recursive: true }); return true; }
      catch (e) { console.warn('Speichern fehlgeschlagen', e); return false; }
    }
    try { localStorage.setItem('manabu.' + name + '.v1', data); return true; } catch (e) { return false; }
  },
  async del(name) {
    if (FS) { try { await FS.deleteFile({ path: 'manabu/' + name + '.json', directory: 'DATA' }); } catch (e) {} return; }
    try { localStorage.removeItem('manabu.' + name + '.v1'); } catch (e) {}
  }
};
function applyState(st) {
  S.settings = { ...DEFAULTS, ...(st.settings || {}) };
  S.log = st.log || {}; S.gdone = st.gdone || {}; S.tdone = st.tdone || {};
  S.deckMeta = st.deckMeta || null; S.active = st.active || 'b'; S.updatedAt = st.updatedAt || 0;
}
function stateBody() {
  const keys = Object.keys(S.log).sort().slice(-400); const log = {}; keys.forEach(k => log[k] = S.log[k]);
  return { settings: S.settings, log, gdone: S.gdone, tdone: S.tdone, deckMeta: S.deckMeta, active: S.active, updatedAt: S.updatedAt };
}
let saveTimer = null, deckDirty = false, saving = Promise.resolve();
function persist(now) {
  clearTimeout(saveTimer);
  const f = () => {
    const st = stateBody(), sr = S.srs, dk = deckDirty ? (S.deck ? S.deck.map(toRow) : null) : undefined; deckDirty = false;
    saving = saving.then(async () => {
      let ok = await Store.set('state', st) && await Store.set('srs', sr);
      if (dk !== undefined) { if (dk) ok = await Store.set('deck', dk) && ok; else await Store.del('deck'); }
      if (!ok) setSync('err');
    });
    return saving;
  };
  if (now) return f(); saveTimer = setTimeout(f, 400);
}
async function loadAll() {
  const st = await Store.get('state'); if (st) applyState(st);
  const sr = await Store.get('srs'); if (sr && typeof sr === 'object') S.srs = sr;
  if (S.deckMeta) { const dk = await Store.get('deck'); if (Array.isArray(dk)) S.deck = rowsToDeck(dk); }
  if (S.active === 'i' && !S.deck) S.active = 'b';
}
function touch() { S.updatedAt = Date.now(); persist(); }
function touchCard() { touch(); }
function setSync(mode) {
  const text = mode === 'err' ? 'Speichern ist fehlgeschlagen. Ist der Gerätespeicher voll?' : (NATIVE ? 'Fortschritt wird auf diesem Gerät gespeichert.' : 'Fortschritt wird in diesem Browser gespeichert.');
  UI.syncText = text;
  const el = $('#sync'); if (el) { el.className = 'sync ' + (mode === 'err' ? 'err' : 'cloud'); el.querySelector('span').textContent = text; }
}
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') persist(true); });
window.addEventListener('pagehide', () => persist(true));

/* ---------- Sicherung: alles in eine Datei, um Geräte zu wechseln ---------- */
function backupData() { return { app: 'manabu', v: 1, at: new Date().toISOString(), state: stateBody(), srs: S.srs, deck: S.deck ? S.deck.map(toRow) : null }; }
async function exportBackup() {
  await persist(true);
  const name = 'manabu-sicherung-' + dayKey() + '.json', json = JSON.stringify(backupData());
  try {
    if (FS && SHARE) {
      const r = await FS.writeFile({ path: name, directory: 'CACHE', encoding: 'utf8', data: json });
      await SHARE.share({ title: 'Manabu – Sicherung', files: [r.uri], dialogTitle: 'Sicherung speichern oder senden' });
      return;
    }
    const file = new File([json], name, { type: 'application/json' });
    if (navigator.canShare && navigator.canShare({ files: [file] })) { await navigator.share({ files: [file], title: 'Manabu – Sicherung' }); return; }
    const a = document.createElement('a'); a.href = URL.createObjectURL(file); a.download = name; document.body.appendChild(a); a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
    toast('Sicherung heruntergeladen');
  } catch (e) { if (!/cancel|abort/i.test(String(e && (e.message || e.name)))) toast('Sicherung fehlgeschlagen: ' + (e.message || e)); }
}
function readBackup(file) {
  const r = new FileReader();
  r.onload = () => {
    try {
      const b = JSON.parse(String(r.result));
      if (!b || b.app !== 'manabu' || !b.state) throw new Error('Das ist keine Sicherung von Manabu.');
      UI.pendingBackup = b; UI.confirm = 'restore'; render(true);
    } catch (e) { toast(e.message || 'Datei nicht lesbar'); }
  };
  r.readAsText(file, 'utf-8');
}
function restoreBackup() {
  const b = UI.pendingBackup; if (!b) return;
  applyState(b.state); S.srs = b.srs || {}; S.deck = Array.isArray(b.deck) && b.state.deckMeta ? rowsToDeck(b.deck) : null;
  if (!S.deck) S.deckMeta = null; if (S.active === 'i' && !S.deck) S.active = 'b';
  deckDirty = true; SES = null; LIS = null; UI.pendingBackup = null; UI.confirm = null;
  S.updatedAt = Date.now(); persist(true); render(); toast('Sicherung wiederhergestellt');
}

/* ================= Sprachausgabe =================
   App: native Sprachausgabe des Geräts. Web: Web Speech API. */
const TTS = {
  voice: null, ok: false, checked: false, token: 0,
  async init() {
    if (NTTS) {
      try { const r = await NTTS.isLanguageSupported({ lang: 'ja-JP' }); this.ok = !!r.supported; } catch (e) { this.ok = true; }
      this.checked = true; if (!this.ok && ['listen', 'settings'].includes(UI.view)) render(true); return;
    }
    if (!('speechSynthesis' in window)) { this.checked = true; return; }
    const pick = () => {
      const ja = speechSynthesis.getVoices().filter(v => /^ja/i.test(v.lang));
      this.voice = ja.find(v => /google|kyoko|nanami|haruka|ayumi|o-ren|siri/i.test(v.name)) || ja[0] || null;
      this.ok = !!this.voice;
    };
    pick(); speechSynthesis.onvoiceschanged = () => { pick(); this.checked = true; };
    setTimeout(() => { pick(); this.checked = true; if (['listen', 'settings'].includes(UI.view) && !this.ok) render(true); }, 1500);
  },
  speak(text, opt = {}) {
    const done = () => opt.onend && opt.onend();
    if (!text) { done(); return; }
    const my = ++this.token, rate = opt.rate || S.settings.rate;
    if (NTTS) {
      NTTS.stop().catch(() => {}).then(() => {
        if (my !== this.token) return;
        NTTS.speak({ text, lang: 'ja-JP', rate, pitch: 1, volume: 1, category: 'playback', queueStrategy: 0 })
          .then(() => { if (my === this.token) done(); }, () => { if (my === this.token) done(); });
      });
      return;
    }
    if (!('speechSynthesis' in window)) { done(); return; }
    try {
      speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text);
      u.lang = 'ja-JP'; if (this.voice) u.voice = this.voice; u.rate = rate;
      u.onend = () => { if (my === this.token) done(); }; u.onerror = u.onend;
      speechSynthesis.speak(u);
    } catch (e) { done(); }
  },
  stop() { this.token++; if (NTTS) { NTTS.stop().catch(() => {}); return; } try { speechSynthesis.cancel(); } catch (e) {} }
};
function voiceNote() {
  if (NTTS) {
    if (!TTS.checked || TTS.ok) return '';
    return PLATFORM === 'android'
      ? '<div class="note">Auf diesem Handy fehlt die japanische Sprachausgabe. Installiere sie in den Android-Einstellungen unter „Sprachausgabe“ (Google-Sprachausgabe → Japanisch). <button class="link" data-a="ttsinstall">Einstellungen öffnen</button></div>'
      : '<p class="note">Auf diesem iPhone fehlt eine japanische Stimme: Einstellungen → Bedienungshilfen → Gesprochene Inhalte → Stimmen → Japanisch.</p>';
  }
  if (!('speechSynthesis' in window)) return '<p class="note">Dieser Browser hat keine Sprachausgabe. Öffne die App in Safari, Chrome oder Edge, um Wörter und Sätze zu hören.</p>';
  if (TTS.checked && !TTS.ok) return '<p class="note">Auf diesem Gerät ist keine japanische Stimme installiert. iPhone: Einstellungen → Bedienungshilfen → Gesprochene Inhalte → Stimmen → Japanisch. Windows: Einstellungen → Zeit und Sprache → Sprache → Japanisch hinzufügen.</p>';
  return '';
}

/* ================= Wiederholungs-Algorithmus ================= */
/* Karte: [fällig(ms), Intervall(Tage), Ease(‰), Wiederholungen, Fehler, Schritt]; Schritt -1 = Wiederholung, 0..n = Lernphase, 100+ = Neu-Lernen */
function fuzz(n) { if (n < 3) return n; const f = Math.max(1, Math.round(n * 0.05)); return n + Math.round((Math.random() * 2 - 1) * f); }
function schedule(prev, ok, now = Date.now(), useFuzz = true) {
  let [due, ivl, ease, reps, lapses, step] = prev ? prev : [now, 0, 2500, 0, 0, 0];
  reps++;
  if (step === -1) {
    if (ok) { let n = Math.max(ivl + 1, Math.round(ivl * ease / 1000)); if (useFuzz) n = Math.max(ivl + 1, fuzz(n)); ivl = Math.min(n, 3650); due = dayStart(now) + ivl * DAY; }
    else { lapses++; ease = Math.max(1300, ease - 200); ivl = Math.max(1, Math.round(ivl * 0.5)); step = 100; due = now + RELEARN_STEPS[0] * MIN; }
  } else if (step >= 100) {
    if (ok) { const k = step - 100 + 1; if (k >= RELEARN_STEPS.length) { step = -1; due = dayStart(now) + ivl * DAY; } else { step = 100 + k; due = now + RELEARN_STEPS[k] * MIN; } }
    else { step = 100; due = now + RELEARN_STEPS[0] * MIN; }
  } else {
    if (ok) { const k = step + 1; if (k >= LEARN_STEPS.length) { step = -1; ivl = 1; due = dayStart(now) + DAY; } else { step = k; due = now + LEARN_STEPS[k] * MIN; } }
    else { step = 0; due = now + LEARN_STEPS[0] * MIN; }
  }
  return [due, ivl, ease, reps, lapses, step];
}
function fmtDays(d) { if (d < 30) return d + ' T'; if (d < 365) return String(Math.round(d / 3) / 10).replace('.', ',') + ' Mon'; return String(Math.round(d / 36.5) / 10).replace('.', ',') + ' J'; }
function fmtNext(c, now) { if (c[5] === -1) return fmtDays(c[1]); const m = Math.max(1, Math.round((c[0] - now) / MIN)); return m < 60 ? '< ' + m + ' Min' : Math.round(m / 60) + ' Std'; }
function status(w) { const c = S.srs[w.id]; if (!c) return 'new'; if (c[5] !== -1) return 'learn'; return c[1] >= 21 ? 'mature' : 'young'; }
const STATUS_LABEL = { new: 'Neu', learn: 'Lernend', young: 'Jung', mature: 'Gefestigt' };
function counts(now = Date.now()) {
  const lg = todayLog(); let newAvail = 0, due = 0, learnDue = 0, learnAll = 0, nextLearn = Infinity;
  for (const w of activeWords()) {
    const c = S.srs[w.id];
    if (!c) newAvail++;
    else if (c[5] === -1) { if (c[0] <= now) due++; }
    else { learnAll++; if (c[0] <= now + 20 * MIN) learnDue++; else nextLearn = Math.min(nextLearn, c[0]); }
  }
  const newLeft = Math.min(newAvail, Math.max(0, S.settings.newPerDay + (lg.x || 0) - lg.n));
  return { newLeft, newAvail, due, learnDue, learnAll, nextLearn, total: newLeft + due + learnDue };
}

/* ================= UI-Zustand ================= */
const NAV = [['home', 'Heute', '今'], ['review', 'Wiederholen', '復'], ['grammar', 'Grammatik', '文'], ['read', 'Lesen', '読'], ['listen', 'Hören', '聞'], ['words', 'Wörter', '単'], ['settings', 'Deck & Optionen', '設']];
const UI = { view: 'home', lesson: null, text: null, words: { q: '', f: 'all', page: 0, open: null }, imp: null, confirm: null, qa: {}, qo: {}, trAll: false, tr: {}, syncText: '', pendingBackup: null };
let SES = null, LIS = null;
const READER = { playing: false, idx: -1 };

const TABS = ['home', 'review', 'grammar', 'read', 'listen'];
const TAB_SHORT = { home: 'Heute', review: 'Karten', grammar: 'Grammatik', read: 'Lesen', listen: 'Hören' };
function buildNav() {
  $('#nav').innerHTML = NAV.map(([v, l, k]) => '<button data-a="go" data-v="' + v + '"><span class="k" aria-hidden="true">' + k + '</span><span>' + l + '</span>' + (v === 'review' ? '<span class="badge" data-badge hidden></span>' : '') + '</button>').join('');
  $('#tabs').innerHTML = TABS.map(v => { const n = NAV.find(x => x[0] === v); return '<button data-a="go" data-v="' + v + '"><span class="k" aria-hidden="true">' + n[2] + '</span><span>' + TAB_SHORT[v] + '</span>' + (v === 'review' ? '<span class="badge" data-badge hidden></span>' : '') + '</button>'; }).join('');
  $('#topbtns').innerHTML = '<button class="tb" data-a="go" data-v="words" aria-label="Wörter"><span class="k" aria-hidden="true">単</span>Wörter</button><button class="tb" data-a="go" data-v="settings" aria-label="Deck und Optionen"><span class="k" aria-hidden="true">設</span></button>';
}
function render(keepScroll) {
  document.querySelectorAll('#nav button, #tabs button, #topbtns button').forEach(b => b.classList.toggle('on', b.dataset.v === UI.view));
  const c = counts(); document.querySelectorAll('[data-badge]').forEach(bd => { bd.textContent = c.total > 999 ? '999+' : c.total; bd.hidden = !c.total; });
  const n = NAV.find(x => x[0] === UI.view); $('#tt').textContent = n ? n[1] : '';
  const fn = { home: vHome, review: vReview, grammar: vGrammar, read: vRead, listen: vListen, words: vWords, settings: vSettings }[UI.view];
  $('#main').innerHTML = '<div class="wrap">' + fn() + '</div>';
  if (!keepScroll) window.scrollTo(0, 0);
}
function go(v) { if (UI.view !== v) { TTS.stop(); READER.playing = false; } UI.view = v; UI.confirm = null; render(); }
/* Zurück-Taste (Android): erst innerhalb der App zurück, auf „Heute“ die App schließen */
function goBack() {
  if (UI.confirm) { UI.confirm = null; render(true); return true; }
  if (UI.view === 'review' && SES) { SES = null; TTS.stop(); render(); return true; }
  if (UI.view === 'listen' && LIS) { LIS = null; TTS.stop(); render(); return true; }
  if (UI.view === 'grammar' && UI.lesson !== null) { UI.lesson = null; TTS.stop(); render(); return true; }
  if (UI.view === 'read' && UI.text !== null) { UI.text = null; READER.playing = false; TTS.stop(); render(); return true; }
  if (UI.view === 'settings' && UI.imp) { UI.imp = null; render(true); return true; }
  if (UI.view !== 'home') { go('home'); return true; }
  return false;
}

/* ================= Ansicht: Heute ================= */
function installHint() {
  if (NATIVE || STANDALONE || S.settings.hideInstall) return '';
  const how = IS_IOS ? 'Tippe in Safari auf <b>Teilen</b> und dann auf <b>„Zum Home-Bildschirm“</b>.' : 'Öffne das Browser-Menü und wähle <b>„App installieren“</b> oder <b>„Zum Startbildschirm hinzufügen“</b>.';
  return '<section class="panel install"><span class="k" aria-hidden="true">学</span><div style="display:flex;flex-direction:column;gap:6px;min-width:0"><h2>Als App installieren</h2><p class="muted small">' + how + ' Danach startet Manabu wie eine normale App, im Vollbild und auch ohne Internet.</p><div><button class="link" data-a="hideinstall">Ausblenden</button></div></div></section>';
}
function vHome() {
  const now = Date.now(), c = counts(now), lg = todayLog(), words = activeWords();
  const pr = { new: 0, learn: 0, young: 0, mature: 0 }; words.forEach(w => pr[status(w)]++);
  const total = words.length;
  // Prognose 14 Tage
  const ds = dayStart(now), fc = Array(14).fill(0);
  for (const w of words) { const x = S.srs[w.id]; if (!x) continue; const k = x[0] < ds + DAY ? 0 : Math.floor((x[0] - ds) / DAY); if (k >= 0 && k < 14) fc[k]++; }
  const mx = Math.max(1, ...fc);
  const fcHtml = fc.map((v, i) => { const d = new Date(ds + i * DAY + 12 * 3600000); return '<div class="col' + (i === 0 ? ' today' : '') + '" title="' + v + ' Karten"><span class="v">' + (v || '') + '</span><span class="b" style="height:' + Math.round(v / mx * 82) + 'px"></span><span class="d">' + (i === 0 ? '今' : '日月火水木金土'[d.getDay()]) + '</span></div>'; }).join('');
  // Serie
  let streak = 0; for (let i = 0; i < 400; i++) { const k = dayKey(now - i * DAY); if (S.log[k] && S.log[k].r > 0) streak++; else if (i > 0) break; }
  const pct = lg.r ? Math.round(lg.c / lg.r * 100) + ' %' : '–';
  const seg = (n, col) => n ? '<span style="width:' + (n / total * 100) + '%;background:' + col + '"></span>' : '';
  const gNext = GRAMMAR.findIndex((g, i) => !S.gdone[i]); const tNext = TEXTS.findIndex((t, i) => !S.tdone[i]);
  return `
  <header class="pagehead"><span class="eyebrow jpd">${jpDate(now)}</span><h1 class="hide-m">Heute</h1></header>
  ${installHint()}
  <section class="panel today">
    <div class="nums">
      <div class="num"><span class="n" style="color:var(--new)">${c.newLeft}</span><span class="l">Neue Wörter</span></div>
      <div class="num"><span class="n" style="color:var(--learn)">${c.learnDue}</span><span class="l">In der Lernphase</span></div>
      <div class="num"><span class="n" style="color:var(--good)">${c.due}</span><span class="l">Fällig</span></div>
    </div>
    ${c.total ? `<button class="btn primary big" data-a="startrev">Wiederholen · ${c.total}</button>` : `<button class="btn big" data-a="go" data-v="listen">Für heute fertig – Hören üben</button>`}
    <p class="meta">${esc(deckName())} · ${total} Wörter · ${S.settings.newPerDay} neue pro Tag</p>
  </section>
  <section class="stats">
    <div class="stat"><b>${lg.r}</b><span>Karten heute (${pct} gewusst)</span></div>
    <div class="stat"><b>${streak} ${streak === 1 ? 'Tag' : 'Tage'}</b><span>Lernserie</span></div>
    <div class="stat"><b>${total - pr.new} / ${total}</b><span>Wörter begonnen</span></div>
  </section>
  <section class="grid2">
    <div class="panel"><h2>Fällige Karten, nächste 14 Tage</h2><div class="fc" role="img" aria-label="Prognose der fälligen Karten">${fcHtml}</div></div>
    <div class="panel"><h2>Stand im Deck</h2>
      <div class="prog">${seg(pr.mature, 'var(--mature)')}${seg(pr.young, 'var(--good)')}${seg(pr.learn, 'var(--learn)')}</div>
      <div class="legend">
        <div><i style="background:var(--mature)"></i>Gefestigt (ab 21 Tagen)<b>${pr.mature}</b></div>
        <div><i style="background:var(--good)"></i>Jung<b>${pr.young}</b></div>
        <div><i style="background:var(--learn)"></i>Lernend<b>${pr.learn}</b></div>
        <div><i style="background:var(--sunk);border:1px solid var(--line)"></i>Noch neu<b>${pr.new}</b></div>
      </div>
    </div>
  </section>
  <section class="panel"><h2>Weiter mit</h2>
    <div class="nextlist">
      <button class="tile" data-a="opengram" data-i="${gNext < 0 ? 0 : gNext}"><span class="k">文</span><b>${gNext < 0 ? 'Alle Lektionen erledigt' : 'Lektion ' + (gNext + 1)}</b><span>${esc(GRAMMAR[gNext < 0 ? 0 : gNext].t)}</span></button>
      <button class="tile" data-a="opentext" data-i="${tNext < 0 ? 0 : tNext}"><span class="k">読</span><b>${esc(TEXTS[tNext < 0 ? 0 : tNext].t)}</b><span>${esc(TEXTS[tNext < 0 ? 0 : tNext].de)} · Stufe ${TEXTS[tNext < 0 ? 0 : tNext].lv}</span></button>
      <button class="tile" data-a="go" data-v="listen"><span class="k">聞</span><b>Hörtraining</b><span>10 Wörter oder Sätze verstehen</span></button>
    </div>
  </section>`;
}

/* ================= Ansicht: Wiederholen ================= */
function learningIds() { const a = []; for (const w of activeWords()) { const c = S.srs[w.id]; if (c && c[5] !== -1) a.push(w.id); } return a; }
function startSession() {
  const now = Date.now(), c = counts(now);
  const reviews = [], fresh = [];
  for (const w of activeWords()) { const x = S.srs[w.id]; if (!x) { if (fresh.length < c.newLeft) fresh.push(w.id); } else if (x[5] === -1 && x[0] <= now) reviews.push(w.id); }
  shuffle(reviews);
  const main = []; const gap = fresh.length ? Math.max(1, Math.floor(reviews.length / fresh.length)) : reviews.length;
  let ri = 0, ni = 0;
  while (ri < reviews.length || ni < fresh.length) { for (let k = 0; k < gap && ri < reviews.length; k++) main.push(reviews[ri++]); if (ni < fresh.length) main.push(fresh[ni++]); }
  SES = { main, idx: 0, cur: null, last: null, revealed: false, mode: 'read', history: [], ok: 0, bad: 0, speak: false };
  nextCard();
  UI.view = 'review'; render();
  autoSpeak();
}
function pickNext() {
  const now = Date.now();
  const learn = learningIds().sort((a, b) => S.srs[a][0] - S.srs[b][0]);
  const dueNow = learn.filter(id => S.srs[id][0] <= now);
  if (dueNow.length) return dueNow[0] === SES.last && dueNow.length > 1 && SES.idx >= SES.main.length ? dueNow[1] : dueNow[0];
  while (SES.idx < SES.main.length) {
    const id = SES.main[SES.idx++]; const c = S.srs[id];
    if (!c || (c[5] === -1 && c[0] <= now)) return id;
  }
  const ahead = learn.filter(id => S.srs[id][0] <= now + 20 * MIN);
  if (ahead.length) return ahead[0] === SES.last && ahead.length > 1 ? ahead[1] : ahead[0];
  return null;
}
function nextCard() {
  SES.cur = pickNext(); SES.revealed = false;
  const m = S.settings.cardMode; SES.mode = m === 'mix' ? (Math.random() < .5 ? 'listen' : 'read') : m;
  SES.speak = !!SES.cur && SES.mode === 'listen';
}
function autoSpeak() { if (SES && SES.cur && SES.speak) { SES.speak = false; TTS.speak(sayableWord(wordById(SES.cur))); } }
function sessionCounts() {
  const now = Date.now(); let n = 0, r = 0;
  for (let i = SES.idx; i < SES.main.length; i++) { const c = S.srs[SES.main[i]]; if (!c) n++; else if (c[5] === -1 && c[0] <= now) r++; }
  let l = learningIds().filter(id => S.srs[id][0] <= now + 20 * MIN && id !== SES.cur).length;
  if (SES.cur) { const c = S.srs[SES.cur]; if (!c) n++; else if (c[5] === -1) r++; else l++; }
  return { n, r, l };
}
function reveal() { if (!SES || !SES.cur || SES.revealed) return; SES.revealed = true; render(true); if (SES.mode === 'read' && S.settings.autoAudio) TTS.speak(sayableWord(wordById(SES.cur))); }
function answerCard(ok) {
  if (!SES || !SES.cur || !SES.revealed) return;
  const id = SES.cur, prev = S.srs[id] ? S.srs[id].slice() : null;
  SES.history.push({ id, prev, ok });
  S.srs[id] = schedule(prev, ok);
  const L = todayLog(); L.r++; if (ok) L.c++; if (!prev) L.n++;
  ok ? SES.ok++ : SES.bad++;
  touchCard(id);
  SES.last = id; TTS.stop(); nextCard(); render(true); autoSpeak();
}
function undo() {
  if (!SES || !SES.history.length) return;
  const h = SES.history.pop();
  if (h.prev) S.srs[h.id] = h.prev; else delete S.srs[h.id];
  const L = todayLog(); L.r = Math.max(0, L.r - 1); if (h.ok) L.c = Math.max(0, L.c - 1); if (!h.prev) L.n = Math.max(0, L.n - 1);
  h.ok ? SES.ok-- : SES.bad--;
  if (SES.cur && SES.idx > 0 && SES.main[SES.idx - 1] === SES.cur) SES.idx--;
  SES.cur = h.id; SES.revealed = true;
  touchCard(h.id); render(true); toast('Letzte Antwort zurückgenommen');
}
function vReview() {
  if (!SES) {
    const c = counts();
    return `<header class="pagehead"><span class="eyebrow jpd">復習</span><h1>Wiederholen</h1></header>
    <section class="panel today">
      <div class="nums">
        <div class="num"><span class="n" style="color:var(--new)">${c.newLeft}</span><span class="l">Neu</span></div>
        <div class="num"><span class="n" style="color:var(--learn)">${c.learnDue}</span><span class="l">Lernphase</span></div>
        <div class="num"><span class="n" style="color:var(--good)">${c.due}</span><span class="l">Fällig</span></div>
      </div>
      ${c.total ? '<button class="btn primary big" data-a="startrev">Starten</button>' : ''}
      <p class="meta">${esc(deckName())} · Vorderseite: ${{ read: 'Wort lesen', listen: 'Wort hören', mix: 'gemischt' }[S.settings.cardMode]}</p>
    </section>
    ${c.total ? '' : `<section class="panel"><h2>Für heute ist alles erledigt</h2>
      <p class="muted">${c.learnAll ? c.learnAll + ' Karten in der Lernphase kommen ' + (c.nextLearn < Infinity ? 'in ' + Math.max(1, Math.round((c.nextLearn - Date.now()) / MIN)) + ' Min. ' : '') + 'wieder. ' : ''}${c.newAvail ? 'Wenn du mehr schaffen willst, kannst du heute zusätzliche neue Wörter freischalten.' : 'Alle Wörter dieses Decks sind begonnen.'}</p>
      ${c.newAvail ? '<div class="row"><button class="btn" data-a="extra">+10 neue Wörter heute</button></div>' : ''}</section>`}
    <section class="panel"><h2>So funktioniert es</h2>
      <p class="muted">Schau dir das Wort an (oder hör es dir an) und überlege, was es bedeutet. Dann deck die Karte auf. Wusstest du es, wird der Abstand bis zur nächsten Abfrage größer – etwa 1, 3, 8, 20 Tage. Wusstest du es nicht, kommt die Karte nach wenigen Minuten wieder und der Abstand wird kürzer.</p></section>`;
  }
  if (!SES.cur) {
    const c = counts(), n = SES.ok + SES.bad;
    return `<section class="panel done-hero"><span class="jbig">お疲れさまでした！</span><h1>Runde geschafft</h1>
      <p class="lead">${n} Karten, davon ${SES.ok} gewusst${n ? ' (' + Math.round(SES.ok / n * 100) + ' %)' : ''}.
      ${c.learnAll ? c.learnAll + ' Karten aus der Lernphase kommen später heute wieder – dann wird die Zahl in der Seitenleiste angezeigt.' : ''}</p>
      <div class="row"><button class="btn primary" data-a="endses" data-v="home">Zur Übersicht</button><button class="btn" data-a="endses" data-v="listen">Hören üben</button><button class="btn" data-a="endses" data-v="read">Einen Text lesen</button></div></section>`;
  }
  const w = wordById(SES.cur), c = S.srs[SES.cur], sc = sessionCounts();
  const tag = !c ? '<span class="chip new">Neu</span>' : c[5] === -1 ? '<span class="chip young">Wiederholung</span>' : '<span class="chip learn">Lernphase</span>';
  const listenFront = SES.mode === 'listen';
  const front = listenFront ? '<button class="play-big" data-a="sayword">' + ICON.speaker + '<span>Nochmal anhören</span></button>' : '<div class="word" lang="ja">' + esc(plain(w.w)) + '</div>';
  let back = '', btns;
  if (SES.revealed) {
    const rd = readingOf(w);
    back = `<div class="backside">
      ${listenFront ? '<div class="word" lang="ja" style="font-size:48px;text-align:left;padding:0;background:none">' + esc(plain(w.w)) + '</div>' : ''}
      <div class="reading" lang="ja">${esc(rd)}<button class="icon" data-a="sayword" aria-label="Wort anhören">${ICON.speaker}</button></div>
      <div class="meaning">${esc(w.m)}</div>
      ${w.p ? '<div class="pos">' + esc(w.p) + '</div>' : ''}
      ${w.s ? '<div class="ex"><div class="ex-jp" lang="ja"><span>' + jp(w.s) + '</span><button class="icon sm" data-a="saysent" aria-label="Satz anhören">' + ICON.speaker + '</button></div>' + (w.t ? '<div class="ex-de">' + esc(w.t) + '</div>' : '') + '</div>' : ''}
    </div>`;
    const now = Date.now(), prev = S.srs[SES.cur];
    btns = '<button class="btn again" data-a="ans" data-ok="0">Nicht gewusst<small>' + fmtNext(schedule(prev, false, now, false), now) + '</small></button><button class="btn good" data-a="ans" data-ok="1">Gewusst<small>' + fmtNext(schedule(prev, true, now, false), now) + '</small></button>';
  } else btns = '<button class="btn primary big wide" data-a="reveal">Aufdecken</button>';
  return `<div class="ses-top">
      <div class="counts"><span style="color:var(--new)">${sc.n}<small>neu</small></span><span style="color:var(--learn)">${sc.l}<small>lernen</small></span><span style="color:var(--good)">${sc.r}<small>fällig</small></span></div>
      <span class="sp"></span>
      ${SES.history.length ? '<button class="link" data-a="undo">Rückgängig</button>' : ''}
      <button class="btn" data-a="endses" data-v="review">Beenden</button>
    </div>
    <article class="flash${SES.revealed ? ' open' : ''}"><div class="flash-tag">${tag}</div><div class="flash-front">${front}</div>${back}</article>
    <div class="answer">${btns}</div>
    <p class="keys"><kbd>Leertaste</kbd> ${SES.revealed ? 'Gewusst' : 'Aufdecken'} · <kbd>1</kbd> Nicht gewusst · <kbd>2</kbd> Gewusst · <kbd>R</kbd> Anhören · <kbd>Z</kbd> Rückgängig</p>`;
}

/* ================= Quiz-Baustein ================= */
function quizHTML(key, items) {
  return '<div class="quiz">' + items.map((it, i) => {
    const k = key + ':' + i;
    if (!UI.qo[k]) UI.qo[k] = shuffle(it.o.map((_, j) => j));
    const ans = UI.qa[k];
    const opts = UI.qo[k].map(j => {
      let cls = 'opt'; if (ans !== undefined) { if (j === 0) cls += ' right'; else if (j === ans) cls += ' wrong'; }
      return '<button class="' + cls + '" data-a="qans" data-k="' + k + '" data-j="' + j + '"' + (ans !== undefined ? ' disabled' : '') + '>' + esc(it.o[j]) + '</button>';
    }).join('');
    const q = it.jp ? '<div class="qt jp" lang="ja">' + jp(it.q) + '</div>' : '<div class="qt">' + esc(it.q) + '</div>';
    return '<div class="qq"><span class="eyebrow">Frage ' + (i + 1) + '</span>' + q + '<div class="opts">' + opts + '</div>' + (ans !== undefined && it.e ? '<p class="expl">' + (ans === 0 ? 'Richtig. ' : 'Nicht ganz. ') + esc(it.e) + '</p>' : (ans !== undefined ? '<p class="expl">' + (ans === 0 ? 'Richtig.' : 'Nicht ganz – die richtige Antwort ist markiert.') + '</p>' : '')) + '</div>';
  }).join('') + '</div>';
}
function quizScore(key, n) { let a = 0, r = 0; for (let i = 0; i < n; i++) { const v = UI.qa[key + ':' + i]; if (v !== undefined) { a++; if (v === 0) r++; } } return { a, r }; }

/* ================= Ansicht: Grammatik ================= */
function vGrammar() {
  if (UI.lesson === null) {
    const n = Object.keys(S.gdone).length;
    return `<header class="pagehead"><span class="eyebrow jpd">文法</span><h1>Grammatik</h1></header>
    <p class="lead">Dreizehn kurze Lektionen mit den Mustern, die in Anfängertexten ständig vorkommen. Jede Lektion endet mit drei Verständnisfragen. ${n} von ${GRAMMAR.length} erledigt.</p>
    <div class="list">${GRAMMAR.map((g, i) => `<button class="li" data-a="opengram" data-i="${i}"><span class="no">${i + 1}</span><span class="ti"><b>${esc(g.t)}</b><span lang="ja">${esc(g.jp)}</span></span>${S.gdone[i] ? '<span class="chip done">' + ICON.check + 'Erledigt</span>' : '<span></span>'}</button>`).join('')}</div>`;
  }
  const i = UI.lesson, g = GRAMMAR[i], key = 'g' + i;
  const sc = quizScore(key, g.q.length);
  const tbl = g.tbl ? '<div class="tblwrap"><table class="g"><thead><tr>' + g.tbl[0].map(h => '<th>' + esc(h) + '</th>').join('') + '</tr></thead><tbody>' + g.tbl.slice(1).map(r => '<tr>' + r.map(c => '<td>' + esc(c) + '</td>').join('') + '</tr>').join('') + '</tbody></table></div>' : '';
  return `<button class="back" data-a="gramlist">← Alle Lektionen</button>
  <header class="pagehead"><span class="eyebrow">Lektion ${i + 1} von ${GRAMMAR.length}</span><h1>${esc(g.t)}</h1><span class="eyebrow jpd" lang="ja">${esc(g.jp)}</span></header>
  <section class="prose">${g.intro.map(p => '<p>' + p + '</p>').join('')}</section>
  <section class="pattern">${g.pat.map(p => '<div class="pat"><span class="j" lang="ja">' + esc(p[0]) + '</span><span>' + esc(p[1]) + '</span></div>').join('')}</section>
  ${tbl}
  <section class="panel"><h2>Beispiele</h2><div class="exs">${g.ex.map((e, j) => '<div class="exr"><button class="icon sm" data-a="say" data-t="' + esc(kana(e[0])) + '" aria-label="Anhören">' + ICON.speaker + '</button><span class="jp" lang="ja">' + jp(e[0]) + '</span><span class="de">' + esc(e[1]) + '</span></div>').join('')}</div>
  ${g.note ? '<p class="tip">' + esc(g.note) + '</p>' : ''}</section>
  <section class="panel"><h2>Verstehst du es?</h2>${quizHTML(key, g.q)}
  ${sc.a === g.q.length ? '<p class="small"><b>' + sc.r + ' von ' + g.q.length + ' richtig.</b> ' + (sc.r === g.q.length ? 'Lektion erledigt.' : 'Lies die Beispiele noch einmal und versuch es erneut.') + ' <button class="link" data-a="qreset" data-k="' + key + '">Fragen wiederholen</button></p>' : ''}</section>
  <div class="pager">${i > 0 ? '<button class="btn" data-a="opengram" data-i="' + (i - 1) + '">← Lektion ' + i + '</button>' : '<span></span>'}${i < GRAMMAR.length - 1 ? '<button class="btn primary" data-a="opengram" data-i="' + (i + 1) + '">Lektion ' + (i + 2) + ' →</button>' : ''}</div>`;
}

/* ================= Ansicht: Lesen ================= */
function vRead() {
  if (UI.text === null) {
    return `<header class="pagehead"><span class="eyebrow jpd">読む</span><h1>Lesen</h1></header>
    <p class="lead">Kurze Texte mit dem Wortschatz und der Grammatik dieser App. Tippe auf einen Satz, um die Übersetzung zu sehen, oder lass dir den ganzen Text vorlesen.</p>
    <div class="list">${TEXTS.map((t, i) => `<button class="li" data-a="opentext" data-i="${i}"><span class="no" lang="ja">${'一二三四五六七八九十'[i]}</span><span class="ti"><b lang="ja" style="font-family:var(--f-jp)">${esc(t.t)}</b><span style="font-family:var(--f-ui)">${esc(t.de)} · Stufe ${t.lv} · ${t.s.length} Sätze</span></span>${S.tdone[i] ? '<span class="chip done">' + ICON.check + 'Gelesen</span>' : '<span></span>'}</button>`).join('')}</div>`;
  }
  const i = UI.text, t = TEXTS[i], key = 't' + i, sc = quizScore(key, t.q.length);
  return `<button class="back" data-a="textlist">← Alle Texte</button>
  <header class="pagehead"><span class="eyebrow">Stufe ${t.lv} · ${esc(t.de)}</span><h1 lang="ja">${esc(t.t)}</h1></header>
  ${t.note ? '<p class="tip">' + esc(t.note) + '</p>' : ''}
  <div class="toolbar">
    <button class="btn${READER.playing ? ' on' : ''}" data-a="readall">${READER.playing ? ICON.stop + ' Stopp' : ICON.play + ' Ganzen Text anhören'}</button>
    <button class="btn${S.settings.furigana ? ' on' : ''}" data-a="togglefuri">Furigana</button>
    <button class="btn${UI.trAll ? ' on' : ''}" data-a="toggletr">Alle Übersetzungen</button>
  </div>
  <div class="reader">${t.s.map((s, j) => `<div class="sent${READER.playing && READER.idx === j ? ' cur' : ''}"><span class="jp" lang="ja" data-a="tsent" data-j="${j}" role="button" tabindex="0">${jp(s[0])}</span><button class="icon sm" data-a="saytext" data-j="${j}" aria-label="Satz anhören">${ICON.speaker}</button>${(UI.trAll || UI.tr[i + ':' + j]) ? '<span class="de">' + esc(s[1]) + '</span>' : ''}</div>`).join('')}</div>
  <section class="panel"><h2>Verständnisfragen</h2>${quizHTML(key, t.q)}
  ${sc.a === t.q.length ? '<p class="small"><b>' + sc.r + ' von ' + t.q.length + ' richtig.</b> <button class="link" data-a="qreset" data-k="' + key + '">Nochmal</button></p>' : ''}</section>
  <div class="pager">${i > 0 ? '<button class="btn" data-a="opentext" data-i="' + (i - 1) + '">← Vorheriger Text</button>' : '<span></span>'}${i < TEXTS.length - 1 ? '<button class="btn primary" data-a="opentext" data-i="' + (i + 1) + '">Nächster Text →</button>' : ''}</div>`;
}
function readAll() {
  if (READER.playing) { READER.playing = false; TTS.stop(); render(true); return; }
  const t = TEXTS[UI.text]; READER.playing = true; READER.idx = 0;
  const step = () => {
    if (!READER.playing || UI.view !== 'read' || UI.text === null) return;
    if (READER.idx >= t.s.length) { READER.playing = false; READER.idx = -1; render(true); return; }
    render(true);
    TTS.speak(kana(t.s[READER.idx][0]), { onend: () => { READER.idx++; setTimeout(step, 350); } });
  };
  step();
}

/* ================= Ansicht: Hören ================= */
function startListen(mode) {
  const deck = activeWords(); const has = w => mode === 'word' ? !!w.m : !!(w.s && w.t);
  let pool = deck.filter(w => S.srs[w.id] && has(w)), note = '';
  if (S.settings.listenPool === 'all') pool = deck.filter(has);
  else if (pool.length < 6) { note = 'Du hast erst wenige Wörter begonnen, deshalb kommen die ersten Wörter des Decks dran.'; pool = deck.filter(has).slice(0, 60); }
  if (pool.length < 4) { toast('Zu wenige Einträge mit Beispielsätzen in diesem Deck.'); return; }
  const items = shuffle(pool.slice()).slice(0, 10);
  const field = mode === 'word' ? 'm' : 't';
  const all = [...new Set(deck.filter(has).map(w => w[field]))];
  LIS = { mode, note, i: 0, score: 0, res: [], items: items.map(w => {
    const others = shuffle(all.filter(x => x !== w[field])).slice(0, 3);
    return { id: w.id, opts: shuffle([w[field], ...others]), right: w[field] };
  }), ans: null };
  render(); sayListen();
}
function sayListen(rate) { if (!LIS || LIS.i >= LIS.items.length) return; const w = wordById(LIS.items[LIS.i].id); TTS.speak(LIS.mode === 'word' ? sayableWord(w) : kana(w.s), rate ? { rate } : {}); }
function vListen() {
  const vn = voiceNote();
  if (!LIS) return `<header class="pagehead"><span class="eyebrow jpd">聞く</span><h1>Hören</h1></header>
    <p class="lead">Du hörst ein Wort oder einen Satz und wählst die passende Bedeutung. Die Fragen kommen aus den Wörtern, die du schon begonnen hast.</p>${vn}
    <section class="grid2">
      <div class="panel"><h2>Wörter hören</h2><p class="muted">10 einzelne Wörter, je vier Bedeutungen zur Auswahl.</p><button class="btn primary" data-a="lstart" data-m="word">Starten</button></div>
      <div class="panel"><h2>Sätze hören</h2><p class="muted">10 Beispielsätze, je vier Übersetzungen. Schwieriger, aber näher an echtem Japanisch.</p><button class="btn primary" data-a="lstart" data-m="sent">Starten</button></div>
    </section>
    <section class="panel"><div class="set"><div class="lab"><b>Woher kommen die Fragen?</b><span>„Begonnene Wörter“ übt nur, was du schon in der Wiederholung hattest.</span></div>
      <div class="seg" role="radiogroup">${[['known', 'Begonnene Wörter'], ['all', 'Ganzes Deck']].map(([v, l]) => '<label><input type="radio" name="lp" data-set="listenPool" value="' + v + '"' + (S.settings.listenPool === v ? ' checked' : '') + '><span>' + l + '</span></label>').join('')}</div></div></section>`;
  if (LIS.i >= LIS.items.length) {
    const n = LIS.items.length;
    return `<section class="panel done-hero"><span class="jbig">よくできました！</span><h1>${LIS.score} von ${n} verstanden</h1>
      <div class="progress-dots">${LIS.res.map(r => '<i class="' + (r ? 'ok' : 'no') + '"></i>').join('')}</div>
      <div class="row"><button class="btn primary" data-a="lstart" data-m="${LIS.mode}">Neue Runde</button><button class="btn" data-a="lend">Zurück</button></div></section>`;
  }
  const it = LIS.items[LIS.i], w = wordById(it.id);
  const dots = LIS.items.map((_, j) => '<i class="' + (j < LIS.res.length ? (LIS.res[j] ? 'ok' : 'no') : j === LIS.i ? 'cur' : '') + '"></i>').join('');
  const opts = it.opts.map((o, j) => { let cls = 'opt'; if (LIS.ans !== null) { if (o === it.right) cls += ' right'; else if (j === LIS.ans) cls += ' wrong'; } return '<button class="' + cls + '" data-a="lans" data-j="' + j + '"' + (LIS.ans !== null ? ' disabled' : '') + '>' + esc(o) + '</button>'; }).join('');
  const revealHtml = LIS.ans !== null ? (LIS.mode === 'word' ? '<div class="lis-reveal" lang="ja"><b style="font-family:var(--f-jpd);font-size:34px">' + esc(plain(w.w)) + '</b> <span class="muted">' + esc(readingOf(w)) + '</span></div>' : '<div class="lis-reveal" lang="ja">' + jp(w.s) + '</div>') : '';
  return `<div class="ses-top"><span class="eyebrow">${LIS.mode === 'word' ? 'Wörter hören' : 'Sätze hören'} · ${LIS.i + 1} / ${LIS.items.length}</span><span class="sp"></span><button class="btn" data-a="lend">Beenden</button></div>
  ${LIS.note ? '<p class="tip">' + esc(LIS.note) + '</p>' : ''}${vn}
  <section class="panel lis-card">
    <div class="progress-dots">${dots}</div>
    <button class="play-big" data-a="lsay">${ICON.speaker}<span>Anhören</span></button>
    <button class="link" data-a="lslow">Langsamer abspielen</button>
    ${revealHtml}
  </section>
  <div class="opts">${opts}</div>
  ${LIS.ans !== null ? '<button class="btn primary big wide" data-a="lnext">' + (LIS.i + 1 < LIS.items.length ? 'Weiter' : 'Ergebnis') + '</button>' : ''}`;
}

/* ================= Ansicht: Wörter ================= */
function vWords() {
  const W = UI.words, q = W.q.trim().toLowerCase(), words = activeWords();
  let list = words.map((w, i) => [w, i]).filter(([w]) => {
    if (W.f !== 'all') { const s = status(w); if (W.f === 'known' ? !(s === 'young' || s === 'mature') : s !== W.f) return false; }
    if (!q) return true;
    return plain(w.w).includes(q) || kana(w.r).includes(q) || (w.m || '').toLowerCase().includes(q);
  });
  const per = 60, pages = Math.max(1, Math.ceil(list.length / per)); W.page = Math.min(W.page, pages - 1);
  const slice = list.slice(W.page * per, (W.page + 1) * per), now = Date.now();
  const rows = slice.map(([w, i]) => {
    const st = status(w), c = S.srs[w.id];
    const lab = st === 'new' ? 'Neu' : st === 'learn' ? 'Lernend' : (c[0] <= now ? 'Fällig' : 'in ' + fmtDays(Math.max(1, Math.round((c[0] - dayStart(now)) / DAY))));
    let row = `<button class="wrow" data-a="wopen" data-id="${w.id}" aria-expanded="${W.open === w.id}"><span class="nr">${i + 1}</span><span class="w" lang="ja">${esc(plain(w.w))}</span><span class="r" lang="ja">${esc(readingOf(w))}</span><span class="m">${esc(w.m)}</span><span class="chip ${st}">${lab}</span></button>`;
    if (W.open === w.id) row += `<div class="wdetail">
      <div class="row"><button class="icon" data-a="say" data-t="${esc(sayableWord(w))}" aria-label="Wort anhören">${ICON.speaker}</button><span lang="ja" style="font-family:var(--f-jp);font-size:18px">${esc(readingOf(w) || plain(w.w))}</span><span class="muted">${esc(w.m)}</span></div>
      ${w.s ? '<div class="ex-jp" lang="ja"><span>' + jp(w.s) + '</span><button class="icon sm" data-a="say" data-t="' + esc(kana(w.s)) + '" aria-label="Satz anhören">' + ICON.speaker + '</button></div>' + (w.t ? '<div class="ex-de">' + esc(w.t) + '</div>' : '') : ''}
      ${c ? '<p class="small muted">' + c[3] + '× abgefragt, ' + c[4] + '× vergessen' + (c[5] === -1 ? ', Intervall ' + fmtDays(c[1]) : '') + '</p>' : ''}
      <div class="row">${st === 'new' || st === 'learn' ? '<button class="btn" data-a="wknown" data-id="' + w.id + '">Kenne ich schon</button>' : ''}${c ? '<button class="btn" data-a="wreset" data-id="' + w.id + '">Zurücksetzen</button>' : ''}</div></div>`;
    return row;
  }).join('');
  const f = [['all', 'Alle'], ['new', 'Neu'], ['learn', 'Lernend'], ['known', 'Gelernt']];
  return `<header class="pagehead"><span class="eyebrow jpd">単語</span><h1>Wörter</h1></header>
  <div class="filters"><input class="search" id="wq" type="search" placeholder="Suchen: Kanji, Kana oder Bedeutung" value="${esc(W.q)}" autocomplete="off">
    <div class="seg" role="radiogroup">${f.map(([v, l]) => '<label><input type="radio" name="wf" data-a="wfilter" value="' + v + '"' + (W.f === v ? ' checked' : '') + '><span>' + l + '</span></label>').join('')}</div></div>
  <p class="small muted">${esc(deckName())} · ${list.length} ${list.length === 1 ? 'Wort' : 'Wörter'}${pages > 1 ? ' · Seite ' + (W.page + 1) + ' von ' + pages : ''}</p>
  <div class="wlist">${rows || '<p style="padding:16px" class="muted">Keine Treffer.</p>'}</div>
  ${pages > 1 ? '<div class="pager"><button class="btn" data-a="wpage" data-d="-1"' + (W.page ? '' : ' disabled') + '>← Zurück</button><button class="btn" data-a="wpage" data-d="1"' + (W.page < pages - 1 ? '' : ' disabled') + '>Weiter →</button></div>' : ''}`;
}

/* ================= Ansicht: Deck & Optionen ================= */
const ROLES = [['skip', 'Ignorieren'], ['order', 'Nummer (Reihenfolge)'], ['word', 'Wort'], ['reading', 'Lesung (Kana)'], ['meaning', 'Bedeutung'], ['sentence', 'Beispielsatz'], ['trans', 'Satz-Übersetzung'], ['pos', 'Wortart']];
function vSettings() {
  const st = S.settings, im = UI.imp;
  const seg = (key, opts) => '<div class="seg" role="radiogroup">' + opts.map(([v, l]) => '<label><input type="radio" name="s-' + key + '" data-set="' + key + '" value="' + v + '"' + (String(st[key]) === v ? ' checked' : '') + '><span>' + l + '</span></label>').join('') + '</div>';
  const sw = (key) => '<label class="switch"><input type="checkbox" id="sw-' + key + '" data-set="' + key + '"' + (st[key] ? ' checked' : '') + '><span></span></label>';
  let impHtml = '';
  if (im && im.rows) {
    const cols = im.ncol, prev = im.rows.slice(0, 3);
    impHtml = `<div class="panel" style="background:var(--paper)"><h3>Spalten zuordnen · ${esc(im.file)}</h3>
      <p class="small muted">${im.rows.length} Zeilen gefunden. Die Zuordnung ist geraten – prüfe sie anhand der Beispielzeilen. Pflicht sind „Wort“ und „Bedeutung“.</p>
      <div class="tblwrap"><table class="map"><thead><tr>${[...Array(cols)].map((_, j) => '<th><select data-a="role" data-j="' + j + '" aria-label="Spalte ' + (j + 1) + '">' + ROLES.map(([v, l]) => '<option value="' + v + '"' + (im.roles[j] === v ? ' selected' : '') + '>' + l + '</option>').join('') + '</select></th>').join('')}</tr>
      ${im.header ? '<tr>' + [...Array(cols)].map((_, j) => '<th>' + esc(im.header[j] || '') + '</th>').join('') + '</tr>' : ''}</thead>
      <tbody>${prev.map(r => '<tr>' + [...Array(cols)].map((_, j) => '<td title="' + esc(clean(r[j] || '')) + '">' + esc(clean(r[j] || '').slice(0, 40)) + '</td>').join('') + '</tr>').join('')}</tbody></table></div>
      <div class="set"><div class="lab"><b>Name des Decks</b></div><input class="search" id="impname" value="${esc(im.name)}" style="max-width:280px"></div>
      ${im.rows.length > 2000 ? '<div class="set"><div class="lab"><b>Umfang</b><span>Core 2k = die ersten 2000 Wörter nach Nummer.</span></div><div class="seg">' + [['all', 'Alle ' + im.rows.length], ['2000', 'Erste 2000']].map(([v, l]) => '<label><input type="radio" name="implim" data-a="implim" value="' + v + '"' + (im.limit === v ? ' checked' : '') + '><span>' + l + '</span></label>').join('') + '</div></div>' : ''}
      ${S.deck ? '<p class="note">Der Import ersetzt dein bisheriges importiertes Deck „' + esc(S.deckMeta.name) + '“ samt Fortschritt. Das Starter-Deck bleibt unverändert.</p>' : ''}
      ${im.err ? '<p class="note" style="background:var(--again-soft)">' + esc(im.err) + '</p>' : ''}
      <div class="row"><button class="btn primary" data-a="doimport">Importieren</button><button class="btn" data-a="impcancel">Abbrechen</button></div></div>`;
  } else if (im && im.err) impHtml = '<p class="note" style="background:var(--again-soft)">' + esc(im.err) + '</p>';
  const resetName = deckName();
  return `<header class="pagehead"><span class="eyebrow jpd">設定</span><h1>Deck & Optionen</h1></header>
  <section class="panel"><h2>Aktives Deck</h2>
    <div class="decks">
      <button class="deckopt${S.active === 'b' ? ' on' : ''}" data-a="setdeck" data-d="b"><b>Starter-Deck</b><span>160 häufige Grundwörter mit deutschen Bedeutungen und Beispielsätzen.</span></button>
      <button class="deckopt${S.active === 'i' ? ' on' : ''}" data-a="setdeck" data-d="i"${S.deck ? '' : ' disabled'}><b>${S.deck ? esc(S.deckMeta.name) : 'Eigenes Deck'}</b><span>${S.deck ? S.deck.length + ' Wörter, importiert' : 'Noch nichts importiert – z. B. dein Core-2k/6k-Deck aus Anki.'}</span></button>
    </div>
    <p class="small muted">Jedes Deck hat seinen eigenen Fortschritt. Ein Wechsel löscht nichts.</p>
  </section>
  <section class="panel"><h2>Core 2k/6k aus Anki importieren</h2>
    <ol class="steps"><li>Anki am Computer öffnen, Deck auswählen.</li><li>Datei → Exportieren … → Format „Notizen als Klartext (.txt)“ wählen und exportieren.</li><li>Die .txt-Datei aufs Handy bringen, z. B. per Mail, Google Drive oder iCloud.</li><li>Hier „Datei auswählen“ antippen und die Spalten prüfen. HTML und [sound:…]-Verweise werden automatisch entfernt.</li></ol>
    <p class="small muted">Audiodateien aus Anki werden nicht übernommen; die App spricht Wörter und Sätze mit der japanischen Stimme deines Geräts. Furigana im Anki-Format 漢字[かんじ] werden erkannt. CSV-Dateien funktionieren ebenfalls.</p>
    <label class="drop" id="drop"><input type="file" id="file" accept=".txt,.csv,.tsv,text/plain,text/csv"><b>Datei auswählen oder hierher ziehen</b><span class="small muted">.txt, .tsv oder .csv</span></label>
    ${impHtml}
  </section>
  <section class="panel"><h2>Lernen</h2>
    <div class="set"><div class="lab"><b>Neue Wörter pro Tag</b><span>10 sind ein guter Start: das ergibt nach einigen Wochen etwa 60–100 Wiederholungen täglich.</span></div>
      <div class="stepper"><button data-a="npd" data-d="-5" aria-label="Weniger">−</button><output>${st.newPerDay}</output><button data-a="npd" data-d="5" aria-label="Mehr">+</button></div></div>
    <div class="set"><div class="lab"><b>Vorderseite der Karte</b><span>„Hören“ zeigt kein Schriftbild, nur den Klang.</span></div>${seg('cardMode', [['read', 'Wort lesen'], ['listen', 'Wort hören'], ['mix', 'Gemischt']])}</div>
    <div class="set"><div class="lab"><b>Wort beim Aufdecken vorlesen</b></div>${sw('autoAudio')}</div>
  </section>
  <section class="panel"><h2>Anzeige und Audio</h2>
    <div class="set"><div class="lab"><b>Furigana</b><span>Lesehilfe in kleinen Kana über den Kanji.</span></div>${sw('furigana')}</div>
    <div class="set"><div class="lab"><b>Abstände zwischen Wörtern</b><span>Echte japanische Texte haben keine – für den Anfang helfen sie.</span></div>${sw('spaces')}</div>
    <div class="set"><div class="lab"><b>Sprechtempo</b><span>${String(st.rate).replace('.', ',')}×</span></div><div class="row"><input type="range" id="rate" min="0.6" max="1.2" step="0.05" value="${st.rate}" data-set="rate" aria-label="Sprechtempo"><button class="icon" data-a="say" data-t="にほんごを べんきょうしています。" aria-label="Probe anhören">${ICON.speaker}</button></div></div>
    ${voiceNote()}
  </section>
  <section class="panel"><h2>Speicherung und Sicherung</h2>
    <p class="muted">${esc(UI.syncText)} Mit einer Sicherungsdatei nimmst du deinen Fortschritt samt importiertem Deck auf ein neues Handy mit.</p>
    <div class="row"><button class="btn" data-a="backup">Sicherung erstellen</button><label class="btn filebtn">Sicherung laden<input type="file" id="bfile" accept=".json,application/json"></label></div>
    ${UI.confirm === 'restore' && UI.pendingBackup ? '<div class="confirm"><span>Sicherung vom ' + esc(new Date(UI.pendingBackup.at).toLocaleString('de-DE')) + ' laden? Der jetzige Fortschritt auf diesem Gerät wird ersetzt.</span><button class="btn danger" data-a="dorestore">Ja, laden</button><button class="btn" data-a="cancelconfirm">Abbrechen</button></div>' : ''}
    ${UI.confirm === 'reset' ? '<div class="confirm"><span>Fortschritt für „' + esc(resetName) + '“ wirklich löschen? Das lässt sich nicht rückgängig machen.</span><button class="btn danger" data-a="doreset">Ja, löschen</button><button class="btn" data-a="cancelconfirm">Abbrechen</button></div>'
      : UI.confirm === 'deldeck' ? '<div class="confirm"><span>Importiertes Deck „' + esc(S.deckMeta.name) + '“ samt Fortschritt entfernen?</span><button class="btn danger" data-a="dodeldeck">Ja, entfernen</button><button class="btn" data-a="cancelconfirm">Abbrechen</button></div>'
      : '<div class="row"><button class="btn" data-a="confirm" data-c="reset">Fortschritt dieses Decks zurücksetzen</button>' + (S.deck ? '<button class="btn" data-a="confirm" data-c="deldeck">Importiertes Deck entfernen</button>' : '') + '</div>'}
  </section>`;
}

/* ================= Import ================= */
const _ta = document.createElement('textarea');
function clean(s) {
  if (!s) return '';
  let t = String(s).replace(/\[sound:[^\]]*\]/g, '').replace(/<br\s*\/?>/gi, '; ').replace(/<\/(div|p|li)>/gi, '; ').replace(/<[^>]+>/g, '');
  _ta.innerHTML = t; t = _ta.value;
  return t.replace(/ /g, ' ').replace(/[ \t\n]+/g, ' ').replace(/(\s*;\s*)+/g, '; ').replace(/^;\s*|;\s*$/g, '').trim();
}
function parseTable(text) {
  text = text.replace(/^﻿/, '').replace(/\r\n?/g, '\n');
  const lines = text.split('\n'); let start = 0, sep = null;
  while (start < lines.length && lines[start].startsWith('#')) {
    const m = lines[start].match(/^#separator:(.+)$/i);
    if (m) { const v = m[1].trim().toLowerCase(); sep = ({ tab: '\t', comma: ',', semicolon: ';', pipe: '|', space: ' ', colon: ':' })[v] || v; }
    start++;
  }
  const body = lines.slice(start).join('\n');
  if (!sep) { const first = lines[start] || ''; const cand = [['\t', (first.match(/\t/g) || []).length], [';', (first.match(/;/g) || []).length], [',', (first.match(/,/g) || []).length]].sort((a, b) => b[1] - a[1]); sep = cand[0][1] > 0 ? cand[0][0] : '\t'; }
  const rows = []; let row = [], f = '', q = false;
  for (let i = 0; i < body.length; i++) {
    const ch = body[i];
    if (q) { if (ch === '"') { if (body[i + 1] === '"') { f += '"'; i++; } else q = false; } else f += ch; }
    else if (ch === '"' && f === '') q = true;
    else if (ch === sep) { row.push(f); f = ''; }
    else if (ch === '\n') { row.push(f); rows.push(row); row = []; f = ''; }
    else f += ch;
  }
  if (f !== '' || row.length) { row.push(f); rows.push(row); }
  return rows.filter(r => r.some(v => v && v.trim()));
}
function colStats(rows, j) {
  const raw = rows.slice(0, 80), sample = raw.map(r => clean(r[j] || '')).filter(Boolean), n = sample.length || 1;
  const s = { fill: sample.length / Math.max(1, raw.length), num: 0, kanji: 0, kana: 0, jp: 0, lat: 0, br: 0, len: 0, snd: raw.filter(r => /\[sound:/.test(r[j] || '')).length };
  for (const v of sample) {
    if (/^\d+(\.\d+)?$/.test(v)) s.num++; if (RE_K.test(v)) s.kanji++; if (RE_KANA.test(v)) s.kana++;
    if (RE_JP.test(v)) s.jp++; if (RE_LAT.test(v) && !RE_JP.test(v)) s.lat++; if (/\[[^\]]+\]/.test(v)) s.br++; s.len += [...v].length;
  }
  ['num', 'kanji', 'kana', 'jp', 'lat', 'br', 'len'].forEach(k => s[k] /= n);
  return s;
}
function guessRoles(rows, ncol) {
  const st = [...Array(ncol)].map((_, j) => colStats(rows, j)), roles = Array(ncol).fill('skip'), used = new Set();
  const pick = (role, pred, score) => {
    let best = -1, bs = -Infinity;
    st.forEach((s, j) => { if (used.has(j) || s.fill < 0.3 || s.snd > 0 || !pred(s)) return; const sc = score ? score(s, j) : -j; if (sc > bs) { bs = sc; best = j; } });
    if (best >= 0) { roles[best] = role; used.add(best); } return best;
  };
  pick('order', s => s.num > 0.95);
  if (pick('word', s => s.jp > 0.8 && s.len <= 8 && s.br < 0.2, (s, j) => s.kanji - j * 0.01) < 0) pick('word', s => s.jp > 0.8 && s.len <= 14);
  pick('reading', s => s.kana > 0.85 && s.len <= 12);
  pick('meaning', s => s.lat > 0.8 && s.len < 45, (s, j) => -j * 0.01 - (s.len > 25 ? 1 : 0));
  pick('sentence', s => s.jp > 0.8 && s.len > 8, (s, j) => s.br * 2 - j * 0.01);
  pick('trans', s => s.lat > 0.8 && s.len >= 15);
  return roles;
}
function handleFile(file) {
  if (!file) return;
  const r = new FileReader();
  r.onload = () => {
    try {
      let rows = parseTable(String(r.result || ''));
      if (rows.length < 2) { UI.imp = { err: 'In der Datei wurden keine Zeilen gefunden. Exportiere in Anki „Notizen als Klartext (.txt)“.' }; render(true); return; }
      let header = null;
      if (!rows[0].some(v => RE_JP.test(v)) && rows.slice(1, 20).some(r => r.some(v => RE_JP.test(v)))) header = rows.shift();
      const ncol = Math.min(30, Math.max(...rows.slice(0, 100).map(r => r.length)));
      UI.imp = { file: file.name, name: file.name.replace(/\.[^.]+$/, '').replace(/[_-]+/g, ' ').slice(0, 60) || 'Mein Deck', rows, ncol, header, roles: guessRoles(rows, ncol), limit: 'all', err: '' };
    } catch (e) { UI.imp = { err: 'Die Datei konnte nicht gelesen werden: ' + e.message }; }
    render(true);
    const el = document.querySelector('.map'); if (el) el.scrollIntoView({ block: 'center' });
  };
  r.onerror = () => { UI.imp = { err: 'Die Datei konnte nicht gelesen werden.' }; render(true); };
  r.readAsText(file, 'utf-8');
}
function doImport() {
  const im = UI.imp; const nm = $('#impname'); if (nm) im.name = nm.value.trim() || 'Mein Deck';
  if (!im.roles.includes('word') || !im.roles.includes('meaning')) { im.err = 'Ordne mindestens die Spalten „Wort“ und „Bedeutung“ zu.'; render(true); return; }
  let objs = im.rows.map(r => { const o = {}; im.roles.forEach((role, j) => { if (role !== 'skip' && o[role] === undefined) o[role] = clean(r[j] || ''); }); return o; }).filter(o => o.word);
  if (im.roles.includes('order')) objs.sort((a, b) => (parseFloat(a.order) || 1e9) - (parseFloat(b.order) || 1e9));
  if (im.limit === '2000') objs = objs.slice(0, 2000);
  if (!objs.length) { im.err = 'Keine Zeile hat einen Eintrag in der Wort-Spalte.'; render(true); return; }
  for (const id in S.srs) if (id[0] === 'i') delete S.srs[id];
  S.deck = rowsToDeck(objs.map(o => [o.word, o.reading || '', o.meaning || '', o.sentence || '', o.trans || '', o.pos || '']));
  S.deckMeta = { name: im.name, count: S.deck.length, at: Date.now() };
  S.active = 'i'; deckDirty = true; SES = null; LIS = null; UI.imp = null; UI.words.page = 0;
  touch(); render(); toast(S.deck.length + ' Wörter importiert');
}

/* ================= Ereignisse ================= */
const A = {
  go: el => go(el.dataset.v),
  startrev: () => startSession(),
  reveal: () => reveal(),
  ans: el => answerCard(el.dataset.ok === '1'),
  undo: () => undo(),
  endses: el => { SES = null; TTS.stop(); go(el.dataset.v); },
  sayword: () => SES && SES.cur && TTS.speak(sayableWord(wordById(SES.cur))),
  saysent: () => SES && SES.cur && TTS.speak(kana(wordById(SES.cur).s)),
  say: el => TTS.speak(el.dataset.t),
  extra: () => { todayLog().x = (todayLog().x || 0) + 10; touch(); startSession(); },
  opengram: el => { UI.view = 'grammar'; UI.lesson = +el.dataset.i; TTS.stop(); render(); },
  gramlist: () => { UI.lesson = null; render(); },
  opentext: el => { UI.view = 'read'; UI.text = +el.dataset.i; READER.playing = false; TTS.stop(); render(); },
  textlist: () => { UI.text = null; READER.playing = false; TTS.stop(); render(); },
  qans: el => {
    const k = el.dataset.k; UI.qa[k] = +el.dataset.j;
    const [key] = k.split(':'), n = key[0] === 'g' ? GRAMMAR[+key.slice(1)].q.length : TEXTS[+key.slice(1)].q.length;
    const sc = quizScore(key, n);
    if (sc.a === n) { if (key[0] === 'g' && sc.r === n && !S.gdone[+key.slice(1)]) { S.gdone[+key.slice(1)] = 1; touch(); } if (key[0] === 't' && !S.tdone[+key.slice(1)]) { S.tdone[+key.slice(1)] = 1; touch(); } }
    render(true);
  },
  qreset: el => { const key = el.dataset.k; Object.keys(UI.qa).forEach(k => { if (k.startsWith(key + ':')) { delete UI.qa[k]; delete UI.qo[k]; } }); render(true); },
  readall: () => readAll(),
  togglefuri: () => { S.settings.furigana = !S.settings.furigana; touch(); render(true); },
  toggletr: () => { UI.trAll = !UI.trAll; render(true); },
  tsent: el => { const k = UI.text + ':' + el.dataset.j; UI.tr[k] = !UI.tr[k]; render(true); },
  saytext: el => { READER.playing = false; TTS.speak(kana(TEXTS[UI.text].s[+el.dataset.j][0])); },
  lstart: el => startListen(el.dataset.m),
  lsay: () => sayListen(),
  lslow: () => sayListen(0.6),
  lans: el => { if (LIS.ans !== null) return; const it = LIS.items[LIS.i]; LIS.ans = +el.dataset.j; const ok = it.opts[LIS.ans] === it.right; LIS.res.push(ok); if (ok) LIS.score++; render(true); },
  lnext: () => { LIS.i++; LIS.ans = null; render(true); sayListen(); },
  lend: () => { LIS = null; TTS.stop(); render(); },
  wopen: el => { UI.words.open = UI.words.open === el.dataset.id ? null : el.dataset.id; render(true); },
  wpage: el => { UI.words.page += +el.dataset.d; UI.words.open = null; render(); },
  wknown: el => { const id = el.dataset.id, now = Date.now(), prev = S.srs[id]; S.srs[id] = [dayStart(now) + 30 * DAY, 30, 2500, prev ? prev[3] : 0, prev ? prev[4] : 0, -1]; touchCard(id); render(true); toast('Als bekannt markiert – nächste Abfrage in 30 Tagen'); },
  wreset: el => { delete S.srs[el.dataset.id]; touchCard(el.dataset.id); render(true); toast('Wort ist wieder neu'); },
  setdeck: el => { if (el.dataset.d === 'i' && !S.deck) return; S.active = el.dataset.d; SES = null; LIS = null; UI.words.page = 0; touch(); render(true); toast('Aktives Deck: ' + deckName()); },
  npd: el => { S.settings.newPerDay = Math.max(0, Math.min(100, S.settings.newPerDay + +el.dataset.d)); touch(); render(true); },
  impcancel: () => { UI.imp = null; render(true); },
  doimport: () => doImport(),
  confirm: el => { UI.confirm = el.dataset.c; render(true); },
  cancelconfirm: () => { UI.confirm = null; render(true); },
  doreset: () => {
    const p = S.active; for (const id in S.srs) if (id[0] === p) delete S.srs[id];
    SES = null; UI.confirm = null; touch(); render(true); toast('Fortschritt zurückgesetzt');
  },
  backup: () => exportBackup(),
  dorestore: () => restoreBackup(),
  hideinstall: () => { S.settings.hideInstall = true; touch(); render(true); },
  ttsinstall: () => { if (NTTS) NTTS.openInstall().catch(() => {}); },
  dodeldeck: () => {
    for (const id in S.srs) if (id[0] === 'i') delete S.srs[id];
    S.deck = null; S.deckMeta = null; S.active = 'b'; deckDirty = true; SES = null; LIS = null; UI.confirm = null;
    touch(); render(true); toast('Importiertes Deck entfernt');
  }
};
document.addEventListener('click', e => {
  const el = e.target.closest('[data-a]'); if (!el) return;
  if (el.tagName === 'INPUT' || el.tagName === 'SELECT') return;
  const fn = A[el.dataset.a]; if (fn) { e.preventDefault(); fn(el, e); }
});
document.addEventListener('change', e => {
  const el = e.target;
  if (el.id === 'file') { handleFile(el.files && el.files[0]); el.value = ''; return; }
  if (el.id === 'bfile') { if (el.files && el.files[0]) readBackup(el.files[0]); el.value = ''; return; }
  if (el.dataset.a === 'role') { UI.imp.roles[+el.dataset.j] = el.value; UI.imp.err = ''; return; }
  if (el.dataset.a === 'implim') { UI.imp.limit = el.value; return; }
  if (el.dataset.a === 'wfilter') { UI.words.f = el.value; UI.words.page = 0; UI.words.open = null; render(true); return; }
  const key = el.dataset.set; if (!key) return;
  if (el.type === 'checkbox') S.settings[key] = el.checked;
  else if (key === 'rate') S.settings.rate = Math.round(parseFloat(el.value) * 100) / 100;
  else S.settings[key] = el.value;
  touch(); render(true);
  if (key === 'rate') TTS.speak('にほんごを べんきょうしています。');
});
let searchT = null;
document.addEventListener('input', e => {
  if (e.target.id === 'wq') { const v = e.target.value; clearTimeout(searchT); searchT = setTimeout(() => { UI.words.q = v; UI.words.page = 0; UI.words.open = null; render(true); const s = $('#wq'); if (s) { s.focus(); s.setSelectionRange(v.length, v.length); } }, 250); }
  if (e.target.id === 'rate') { const lab = e.target.closest('.set').querySelector('.lab span'); if (lab) lab.textContent = String(e.target.value).replace('.', ',') + '×'; }
  if (e.target.id === 'impname' && UI.imp) UI.imp.name = e.target.value;
});
['dragenter', 'dragover'].forEach(t => document.addEventListener(t, e => { const d = e.target.closest && e.target.closest('#drop'); if (d) { e.preventDefault(); d.classList.add('over'); } }));
document.addEventListener('dragleave', e => { const d = e.target.closest && e.target.closest('#drop'); if (d) d.classList.remove('over'); });
document.addEventListener('drop', e => { const d = e.target.closest && e.target.closest('#drop'); if (d) { e.preventDefault(); d.classList.remove('over'); handleFile(e.dataTransfer.files[0]); } });
document.addEventListener('keydown', e => {
  const tag = (e.target.tagName || '').toLowerCase();
  if (tag === 'input' || tag === 'textarea' || tag === 'select' || e.metaKey || e.ctrlKey || e.altKey) return;
  if (e.target.dataset && e.target.dataset.a === 'tsent' && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); A.tsent(e.target); return; }
  if (UI.view === 'review' && SES && SES.cur) {
    const k = e.key.toLowerCase();
    if (k === ' ' || k === 'enter') { if (tag === 'button' && k === 'enter') return; e.preventDefault(); SES.revealed ? answerCard(true) : reveal(); }
    else if (k === '1' && SES.revealed) answerCard(false);
    else if ((k === '2' || k === '3') && SES.revealed) answerCard(true);
    else if (k === 'r') A.sayword();
    else if (k === 'z') undo();
  } else if (UI.view === 'listen' && LIS && LIS.i < LIS.items.length) {
    if (/^[1-4]$/.test(e.key) && LIS.ans === null) { const b = document.querySelectorAll('[data-a="lans"]')[+e.key - 1]; if (b) A.lans(b); }
    else if ((e.key === 'Enter' || e.key === ' ') && LIS.ans !== null && tag !== 'button') { e.preventDefault(); A.lnext(); }
    else if (e.key.toLowerCase() === 'r') sayListen();
  }
});

/* ================= Start ================= */
(async function start() {
  buildNav();
  try { await loadAll(); } catch (e) { console.warn(e); }
  setSync('ok');
  render();
  TTS.init();
  if (APP) {
    APP.addListener('backButton', () => { if (!goBack()) APP.exitApp(); });
    APP.addListener('pause', () => { TTS.stop(); persist(true); });
    APP.addListener('resume', () => { if (UI.view === 'home' || (UI.view === 'review' && !SES)) render(true); });
  }
  if (!NATIVE && 'serviceWorker' in navigator && location.protocol === 'https:') navigator.serviceWorker.register('sw.js').catch(() => {});
})();
