/* ===== Inhalte: Starter-Wortschatz, Grammatik, Lesetexte =====
   Format Wortschatz: Wort|Lesung|Bedeutung|Beispielsatz (Furigana als 漢字[かな])|Übersetzung */
const STARTER_GROUPS = ['Menschen & Grundwörter','Zahlen & Zeit','Orte & Dinge','Essen & Trinken','Verben','Adjektive','Natur & Alltag','Familie & Funktionswörter'];
const STARTER_RAW = `私|わたし|ich|私[わたし]は 学生[がくせい]です。|Ich bin Student.
あなた|あなた|du, Sie|あなたの 名前[なまえ]は 何[なん]ですか。|Wie heißt du?
人|ひと|Mensch, Person|あの 人[ひと]は 先生[せんせい]です。|Die Person dort ist Lehrer.
男|おとこ|Mann|男[おとこ]の 人[ひと]が います。|Da ist ein Mann.
女|おんな|Frau|女[おんな]の 子[こ]が 歌[うた]って います。|Ein Mädchen singt.
子供|こども|Kind|子供[こども]が 公園[こうえん]で 遊[あそ]んで います。|Die Kinder spielen im Park.
友達|ともだち|Freund(in)|友達[ともだち]と 映画[えいが]を 見[み]ます。|Ich sehe mit Freunden einen Film.
先生|せんせい|Lehrer(in)|先生[せんせい]は 日本人[にほんじん]です。|Der Lehrer ist Japaner.
学生|がくせい|Student(in), Schüler(in)|私[わたし]は 大学[だいがく]の 学生[がくせい]です。|Ich bin Student an der Universität.
名前|なまえ|Name|ここに 名前[なまえ]を 書[か]いて ください。|Schreib bitte hier deinen Namen.
日本|にほん|Japan|日本[にほん]に 行[い]きたいです。|Ich möchte nach Japan fahren.
日本語|にほんご|Japanisch (Sprache)|毎日[まいにち] 日本語[にほんご]を 勉強[べんきょう]します。|Ich lerne jeden Tag Japanisch.
ドイツ|ドイツ|Deutschland|私[わたし]は ドイツから 来[き]ました。|Ich komme aus Deutschland.
これ|これ|dies (hier, bei mir)|これは 私[わたし]の 本[ほん]です。|Das hier ist mein Buch.
それ|それ|das (da, bei dir)|それは 何[なん]ですか。|Was ist das da?
あれ|あれ|das (dort drüben)|あれは 富士山[ふじさん]です。|Das dort drüben ist der Fuji.
何|なに・なん|was|今日[きょう]は 何[なに]を しますか。|Was machst du heute?
誰|だれ|wer|あの 人[ひと]は 誰[だれ]ですか。|Wer ist die Person dort?
はい|はい|ja|はい、そうです。|Ja, genau.
いいえ|いいえ|nein|いいえ、違[ちが]います。|Nein, das stimmt nicht.
一|いち|eins|一月[いちがつ]は 寒[さむ]いです。|Der Januar ist kalt.
二|に|zwei|二時[にじ]に 会[あ]いましょう。|Treffen wir uns um zwei Uhr.
三|さん|drei|三人[さんにん]で 行[い]きます。|Wir gehen zu dritt.
四|よん・し|vier|四月[しがつ]に 日本[にほん]へ 行[い]きます。|Im April fahre ich nach Japan.
五|ご|fünf|五分[ごふん] 待[ま]って ください。|Warte bitte fünf Minuten.
六|ろく|sechs|毎朝[まいあさ] 六時[ろくじ]に 起[お]きます。|Ich stehe jeden Morgen um sechs Uhr auf.
七|なな・しち|sieben|七時[しちじ]に 晩[ばん]ご飯[はん]を 食[た]べます。|Um sieben Uhr esse ich zu Abend.
八|はち|acht|会社[かいしゃ]は 八時[はちじ]からです。|Die Firma fängt um acht Uhr an.
九|きゅう・く|neun|子供[こども]は 九時[くじ]に 寝[ね]ます。|Das Kind geht um neun Uhr schlafen.
十|じゅう|zehn|一[いち]から 十[じゅう]まで 数[かぞ]えます。|Ich zähle von eins bis zehn.
百|ひゃく|hundert|この ペンは 百円[ひゃくえん]です。|Dieser Stift kostet 100 Yen.
千|せん|tausend|切符[きっぷ]は 千円[せんえん]です。|Die Fahrkarte kostet 1000 Yen.
今日|きょう|heute|今日[きょう]は 暑[あつ]いですね。|Heute ist es heiß, nicht wahr?
明日|あした|morgen|明日[あした] 友達[ともだち]に 会[あ]います。|Morgen treffe ich einen Freund.
昨日|きのう|gestern|昨日[きのう]は 雨[あめ]でした。|Gestern hat es geregnet.
今|いま|jetzt|今[いま] 何時[なんじ]ですか。|Wie spät ist es jetzt?
朝|あさ|Morgen (Tageszeit)|朝[あさ]は コーヒーを 飲[の]みます。|Morgens trinke ich Kaffee.
夜|よる|Abend, Nacht|夜[よる]は 静[しず]かです。|Nachts ist es ruhig.
時間|じかん|Zeit; Stunde|時間[じかん]が ありません。|Ich habe keine Zeit.
毎日|まいにち|jeden Tag|毎日[まいにち] 電車[でんしゃ]で 学校[がっこう]へ 行[い]きます。|Ich fahre jeden Tag mit dem Zug zur Schule.
家|いえ|Haus, Zuhause|私[わたし]の 家[いえ]は 駅[えき]の 近[ちか]くです。|Mein Haus ist in der Nähe des Bahnhofs.
学校|がっこう|Schule|学校[がっこう]は 八時[はちじ]に 始[はじ]まります。|Die Schule beginnt um acht.
駅|えき|Bahnhof|駅[えき]は どこですか。|Wo ist der Bahnhof?
店|みせ|Laden, Geschäft|この 店[みせ]は 安[やす]いです。|Dieser Laden ist günstig.
会社|かいしゃ|Firma|父[ちち]は 会社[かいしゃ]で 働[はたら]いて います。|Mein Vater arbeitet in einer Firma.
部屋|へや|Zimmer|私[わたし]の 部屋[へや]は 小[ちい]さいです。|Mein Zimmer ist klein.
町|まち|Stadt, Viertel|この 町[まち]は 静[しず]かです。|Diese Stadt ist ruhig.
国|くに|Land|どこの 国[くに]から 来[き]ましたか。|Aus welchem Land kommst du?
道|みち|Weg, Straße|この 道[みち]を まっすぐ 行[い]って ください。|Gehen Sie diese Straße geradeaus.
車|くるま|Auto|車[くるま]で 海[うみ]へ 行[い]きます。|Wir fahren mit dem Auto ans Meer.
電車|でんしゃ|Zug, Bahn|電車[でんしゃ]は 速[はや]いです。|Der Zug ist schnell.
本|ほん|Buch|図書館[としょかん]で 本[ほん]を 読[よ]みます。|Ich lese in der Bibliothek ein Buch.
机|つくえ|Schreibtisch|机[つくえ]の 上[うえ]に 本[ほん]が あります。|Auf dem Schreibtisch liegt ein Buch.
電話|でんわ|Telefon; Anruf|夜[よる] 母[はは]に 電話[でんわ]します。|Abends rufe ich meine Mutter an.
お金|おかね|Geld|お金[かね]が ありません。|Ich habe kein Geld.
傘|かさ|Regenschirm|雨[あめ]ですから、傘[かさ]を 持[も]って 行[い]きます。|Weil es regnet, nehme ich einen Schirm mit.
鞄|かばん|Tasche|この 鞄[かばん]は 新[あたら]しいです。|Diese Tasche ist neu.
時計|とけい|Uhr|あの 時計[とけい]は 高[たか]いです。|Die Uhr dort ist teuer.
写真|しゃしん|Foto|家族[かぞく]の 写真[しゃしん]を 見[み]せて ください。|Zeig mir bitte ein Foto deiner Familie.
手紙|てがみ|Brief|友達[ともだち]に 手紙[てがみ]を 書[か]きます。|Ich schreibe einem Freund einen Brief.
水|みず|Wasser|水[みず]を ください。|Wasser, bitte.
お茶|おちゃ|(grüner) Tee|お茶[ちゃ]を 飲[の]みませんか。|Möchtest du Tee trinken?
ご飯|ごはん|gekochter Reis; Mahlzeit|ご飯[はん]を 食[た]べましょう。|Lass uns essen.
肉|にく|Fleisch|私[わたし]は 肉[にく]を 食[た]べません。|Ich esse kein Fleisch.
魚|さかな|Fisch|日本人[にほんじん]は よく 魚[さかな]を 食[た]べます。|Japaner essen oft Fisch.
野菜|やさい|Gemüse|野菜[やさい]は 体[からだ]に いいです。|Gemüse ist gut für den Körper.
卵|たまご|Ei|毎朝[まいあさ] 卵[たまご]を 食[た]べます。|Ich esse jeden Morgen ein Ei.
パン|パン|Brot|朝[あさ]ご飯[はん]は パンです。|Zum Frühstück gibt es Brot.
果物|くだもの|Obst|どんな 果物[くだもの]が 好[す]きですか。|Welches Obst magst du?
牛乳|ぎゅうにゅう|Milch|牛乳[ぎゅうにゅう]を 買[か]いました。|Ich habe Milch gekauft.
食べる|たべる|essen|一緒[いっしょ]に 昼[ひる]ご飯[はん]を 食[た]べましょう。|Lass uns zusammen zu Mittag essen.
飲む|のむ|trinken|何[なに]を 飲[の]みますか。|Was trinkst du?
作る|つくる|machen, kochen, herstellen|母[はは]は 料理[りょうり]を 作[つく]って います。|Meine Mutter kocht gerade.
美味しい|おいしい|lecker|この ラーメンは 美味[おい]しいです。|Diese Ramen sind lecker.
甘い|あまい|süß|この ケーキは とても 甘[あま]いです。|Dieser Kuchen ist sehr süß.
辛い|からい|scharf|カレーは 少[すこ]し 辛[から]いです。|Das Curry ist ein bisschen scharf.
朝ご飯|あさごはん|Frühstück|今日[きょう]は 朝[あさ]ご飯[はん]を 食[た]べませんでした。|Heute habe ich nicht gefrühstückt.
晩ご飯|ばんごはん|Abendessen|晩[ばん]ご飯[はん]は 何[なん]ですか。|Was gibt es zum Abendessen?
料理|りょうり|Gericht; Kochen|日本[にほん]の 料理[りょうり]が 好[す]きです。|Ich mag japanisches Essen.
レストラン|レストラン|Restaurant|駅[えき]の 前[まえ]に レストランが あります。|Vor dem Bahnhof gibt es ein Restaurant.
行く|いく|gehen, fahren (hin)|明日[あした] 京都[きょうと]へ 行[い]きます。|Morgen fahre ich nach Kyoto.
来る|くる|kommen|友達[ともだち]が 家[いえ]に 来[き]ます。|Ein Freund kommt zu mir nach Hause.
帰る|かえる|zurückkehren, heimgehen|六時[ろくじ]に 家[いえ]へ 帰[かえ]ります。|Um sechs gehe ich nach Hause.
見る|みる|sehen, anschauen|毎晩[まいばん] テレビを 見[み]ます。|Ich sehe jeden Abend fern.
聞く|きく|hören; fragen|音楽[おんがく]を 聞[き]きます。|Ich höre Musik.
読む|よむ|lesen|電車[でんしゃ]で 本[ほん]を 読[よ]みます。|Ich lese im Zug ein Buch.
書く|かく|schreiben|ひらがなで 名前[なまえ]を 書[か]きます。|Ich schreibe meinen Namen in Hiragana.
話す|はなす|sprechen|ゆっくり 話[はな]して ください。|Sprechen Sie bitte langsam.
買う|かう|kaufen|スーパーで 野菜[やさい]を 買[か]います。|Im Supermarkt kaufe ich Gemüse.
待つ|まつ|warten|駅[えき]で 友達[ともだち]を 待[ま]ちます。|Ich warte am Bahnhof auf einen Freund.
会う|あう|treffen|週末[しゅうまつ]に 先生[せんせい]に 会[あ]いました。|Am Wochenende habe ich den Lehrer getroffen.
ある|ある|vorhanden sein (Dinge)|近[ちか]くに 銀行[ぎんこう]が あります。|In der Nähe gibt es eine Bank.
いる|いる|da sein (Lebewesen)|庭[にわ]に 猫[ねこ]が います。|Im Garten ist eine Katze.
する|する|machen, tun|週末[しゅうまつ]は 何[なに]を しますか。|Was machst du am Wochenende?
起きる|おきる|aufstehen, aufwachen|日曜日[にちようび]は 遅[おそ]く 起[お]きます。|Sonntags stehe ich spät auf.
寝る|ねる|schlafen (gehen)|昨日[きのう]は 早[はや]く 寝[ね]ました。|Gestern bin ich früh schlafen gegangen.
分かる|わかる|verstehen|日本語[にほんご]が 少[すこ]し 分[わ]かります。|Ich verstehe ein bisschen Japanisch.
知る|しる|erfahren; kennen (知っている)|あの 人[ひと]を 知[し]って いますか。|Kennst du die Person dort?
使う|つかう|benutzen|この パソコンを 使[つか]っても いいですか。|Darf ich diesen Computer benutzen?
休む|やすむ|sich ausruhen; frei nehmen|疲[つか]れましたから、少[すこ]し 休[やす]みます。|Ich bin müde, deshalb ruhe ich mich ein bisschen aus.
大きい|おおきい|groß|東京[とうきょう]は 大[おお]きい 町[まち]です。|Tokio ist eine große Stadt.
小さい|ちいさい|klein|小[ちい]さい 犬[いぬ]が います。|Da ist ein kleiner Hund.
新しい|あたらしい|neu|新[あたら]しい 車[くるま]を 買[か]いました。|Ich habe ein neues Auto gekauft.
古い|ふるい|alt (Dinge)|この お寺[てら]は とても 古[ふる]いです。|Dieser Tempel ist sehr alt.
高い|たかい|teuer; hoch|東京[とうきょう]の ホテルは 高[たか]いです。|Hotels in Tokio sind teuer.
安い|やすい|billig, günstig|この 服[ふく]は 安[やす]かったです。|Diese Kleidung war günstig.
良い|いい・よい|gut|今日[きょう]は 天気[てんき]が いいです。|Heute ist schönes Wetter.
悪い|わるい|schlecht|昨日[きのう]は 天気[てんき]が 悪[わる]かったです。|Gestern war das Wetter schlecht.
暑い|あつい|heiß (Wetter)|日本[にほん]の 夏[なつ]は 暑[あつ]いです。|Der Sommer in Japan ist heiß.
寒い|さむい|kalt (Wetter)|今日[きょう]は 寒[さむ]いですから、コートを 着[き]ます。|Heute ist es kalt, deshalb ziehe ich einen Mantel an.
楽しい|たのしい|macht Spaß, fröhlich|旅行[りょこう]は 楽[たの]しかったです。|Die Reise hat Spaß gemacht.
難しい|むずかしい|schwierig|漢字[かんじ]は 難[むずか]しいです。|Kanji sind schwierig.
易しい|やさしい|leicht, einfach|この 問題[もんだい]は 易[やさ]しいです。|Diese Aufgabe ist einfach.
忙しい|いそがしい|beschäftigt|今週[こんしゅう]は とても 忙[いそが]しいです。|Diese Woche bin ich sehr beschäftigt.
静か|しずか|ruhig, still (な-Adj.)|図書館[としょかん]では 静[しず]かに して ください。|Sei in der Bibliothek bitte leise.
有名|ゆうめい|berühmt (な-Adj.)|京都[きょうと]は お寺[てら]で 有名[ゆうめい]です。|Kyoto ist berühmt für seine Tempel.
好き|すき|mögen, gern haben (な-Adj.)|私[わたし]は 猫[ねこ]が 好[す]きです。|Ich mag Katzen.
元気|げんき|gesund, munter (な-Adj.)|お元気[げんき]ですか。|Wie geht es Ihnen?
綺麗|きれい|schön; sauber (な-Adj.)|この 花[はな]は きれいですね。|Diese Blume ist schön, nicht wahr?
便利|べんり|praktisch (な-Adj.)|スマホは とても 便利[べんり]です。|Ein Smartphone ist sehr praktisch.
天気|てんき|Wetter|明日[あした]の 天気[てんき]は どうですか。|Wie wird das Wetter morgen?
雨|あめ|Regen|雨[あめ]が 降[ふ]って います。|Es regnet.
雪|ゆき|Schnee|冬[ふゆ]は 雪[ゆき]が たくさん 降[ふ]ります。|Im Winter schneit es viel.
山|やま|Berg|夏[なつ]に 山[やま]に 登[のぼ]りました。|Im Sommer bin ich auf einen Berg gestiegen.
川|かわ|Fluss|川[かわ]で 魚[さかな]を 釣[つ]ります。|Ich angle im Fluss.
海|うみ|Meer|海[うみ]で 泳[およ]ぎたいです。|Ich möchte im Meer schwimmen.
花|はな|Blume; Blüte|春[はる]には 桜[さくら]の 花[はな]が 咲[さ]きます。|Im Frühling blühen die Kirschblüten.
犬|いぬ|Hund|犬[いぬ]と 散歩[さんぽ]します。|Ich gehe mit dem Hund spazieren.
猫|ねこ|Katze|猫[ねこ]が 寝[ね]て います。|Die Katze schläft.
木|き|Baum; Holz|公園[こうえん]に 大[おお]きい 木[き]が あります。|Im Park steht ein großer Baum.
空|そら|Himmel|空[そら]が 青[あお]いです。|Der Himmel ist blau.
春|はる|Frühling|春[はる]は 暖[あたた]かいです。|Der Frühling ist warm.
夏|なつ|Sommer|夏休[なつやす]みに 旅行[りょこう]します。|In den Sommerferien verreise ich.
秋|あき|Herbst|秋[あき]は 涼[すず]しいです。|Der Herbst ist kühl.
冬|ふゆ|Winter|冬[ふゆ]は 寒[さむ]いです。|Der Winter ist kalt.
仕事|しごと|Arbeit, Job|仕事[しごと]は 九時[くじ]からです。|Die Arbeit beginnt um neun.
勉強|べんきょう|Lernen, Studium|図書館[としょかん]で 勉強[べんきょう]します。|Ich lerne in der Bibliothek.
映画|えいが|Film|週末[しゅうまつ]に 映画[えいが]を 見[み]に 行[い]きます。|Am Wochenende gehe ich ins Kino.
音楽|おんがく|Musik|どんな 音楽[おんがく]が 好[す]きですか。|Welche Musik magst du?
旅行|りょこう|Reise|来年[らいねん] 日本[にほん]へ 旅行[りょこう]します。|Nächstes Jahr reise ich nach Japan.
母|はは|(meine) Mutter|母[はは]は 料理[りょうり]が 上手[じょうず]です。|Meine Mutter kocht gut.
父|ちち|(mein) Vater|父[ちち]は 毎朝[まいあさ] 新聞[しんぶん]を 読[よ]みます。|Mein Vater liest jeden Morgen Zeitung.
家族|かぞく|Familie|私[わたし]の 家族[かぞく]は 四人[よにん]です。|Meine Familie hat vier Personen.
兄|あに|(mein) älterer Bruder|兄[あに]は 東京[とうきょう]に 住[す]んで います。|Mein älterer Bruder wohnt in Tokio.
姉|あね|(meine) ältere Schwester|姉[あね]は 医者[いしゃ]です。|Meine ältere Schwester ist Ärztin.
ここ|ここ|hier|ここは 私[わたし]の 部屋[へや]です。|Hier ist mein Zimmer.
そこ|そこ|da (bei dir)|そこに 座[すわ]って ください。|Setz dich bitte dorthin.
あそこ|あそこ|dort drüben|トイレは あそこです。|Die Toilette ist dort drüben.
どこ|どこ|wo|どこに 住[す]んで いますか。|Wo wohnst du?
いつ|いつ|wann|誕生日[たんじょうび]は いつですか。|Wann hast du Geburtstag?
どう|どう|wie|日本[にほん]の 生活[せいかつ]は どうですか。|Wie ist das Leben in Japan?
一緒に|いっしょに|zusammen|一緒[いっしょ]に 行[い]きませんか。|Wollen wir zusammen gehen?
とても|とても|sehr|この 本[ほん]は とても 面白[おもしろ]いです。|Dieses Buch ist sehr interessant.
少し|すこし|ein bisschen|少[すこ]し 待[ま]って ください。|Warte bitte einen Moment.
もう|もう|schon, bereits|もう 晩[ばん]ご飯[はん]を 食[た]べました。|Ich habe schon zu Abend gegessen.
まだ|まだ|noch (nicht)|まだ 宿題[しゅくだい]を して いません。|Ich habe die Hausaufgaben noch nicht gemacht.
上|うえ|oben; auf|テーブルの 上[うえ]に 鍵[かぎ]が あります。|Auf dem Tisch liegt ein Schlüssel.
下|した|unten; unter|机[つくえ]の 下[した]に 猫[ねこ]が います。|Unter dem Schreibtisch ist eine Katze.
中|なか|innen; in|鞄[かばん]の 中[なか]に 何[なに]が ありますか。|Was ist in der Tasche?
前|まえ|vorne; vor|駅[えき]の 前[まえ]で 待[ま]って います。|Ich warte vor dem Bahnhof.`;

/* Grammatik: o[0] ist immer die richtige Antwort (Reihenfolge wird beim Anzeigen gemischt). */
const GRAMMAR = [
{t:'Thema und Aussage', jp:'AはBです',
 intro:['<span class="j">は</span> markiert das <b>Thema</b> des Satzes: „Was A betrifft, …“. Als Partikel wird は wie <b>wa</b> ausgesprochen.',
        '<span class="j">です</span> steht am Satzende und macht die Aussage höflich. Es entspricht ungefähr „ist / sind“.',
        'Japanisch hat keine Artikel und meist keinen Plural. Was aus dem Zusammenhang klar ist, wird oft weggelassen – auch „ich“.'],
 pat:[['A は B です','A ist B.']],
 ex:[['私[わたし]は 学生[がくせい]です。','Ich bin Student(in).'],['田中[たなか]さんは 先生[せんせい]です。','Herr/Frau Tanaka ist Lehrer(in).'],['これは 本[ほん]です。','Das ist ein Buch.'],['学生[がくせい]です。','(Ich) bin Student(in).']],
 note:'さん ist eine höfliche Anrede hinter Namen. Für sich selbst benutzt man es nie.',
 q:[{q:'私[わたし]は 先生[せんせい]です。',jp:1,o:['Ich bin Lehrer.','Bist du Lehrer?','Ich bin kein Lehrer.','Mein Lehrer.'],e:'私 = ich, は = Thema, 先生 = Lehrer, です = ist.'},
    {q:'Wie wird は als Partikel ausgesprochen?',o:['wa','ha','ba','ga'],e:'Als Partikel liest man は immer „wa“.'},
    {q:'これは 水[みず]です。',jp:1,o:['Das ist Wasser.','Das ist kein Wasser.','Ist das Wasser?','Wasser, bitte.'],e:'これ = dies, 水 = Wasser.'}]},
{t:'Fragen und Verneinung von です', jp:'〜ですか・〜じゃありません',
 intro:['<span class="j">か</span> am Satzende macht aus einer Aussage eine Frage. Ein Fragezeichen braucht man nicht.',
        'Antworten beginnen oft mit <span class="j">はい</span> (ja) oder <span class="j">いいえ</span> (nein).',
        'Die Verneinung von です ist <span class="j">じゃありません</span>; geschrieben und formeller auch <span class="j">ではありません</span>.',
        'Fragewörter wie <span class="j">何</span> (was), <span class="j">誰</span> (wer) und <span class="j">どこ</span> (wo) stehen genau dort, wo später die Antwort steht.'],
 pat:[['A は B ですか','Ist A B?'],['A は B じゃありません','A ist nicht B.']],
 ex:[['学生[がくせい]ですか。','Bist du Student(in)?'],['はい、学生[がくせい]です。','Ja, ich bin Student(in).'],['いいえ、学生[がくせい]じゃありません。','Nein, ich bin kein(e) Student(in).'],['それは 何[なん]ですか。','Was ist das?'],['駅[えき]は どこですか。','Wo ist der Bahnhof?']],
 q:[{q:'田中[たなか]さんは 先生[せんせい]じゃありません。',jp:1,o:['Herr Tanaka ist kein Lehrer.','Herr Tanaka ist Lehrer.','Ist Herr Tanaka Lehrer?','Wer ist Herr Tanaka?'],e:'じゃありません verneint です.'},
    {q:'あの 人[ひと]は 誰[だれ]ですか。',jp:1,o:['Wer ist die Person dort?','Wo ist die Person?','Die Person dort ist nett.','Was ist das dort?'],e:'誰 = wer, か = Frage.'},
    {q:'Was bewirkt か am Satzende?',o:['Der Satz wird zur Frage.','Der Satz wird verneint.','Der Satz steht in der Vergangenheit.','Der Satz wird höflicher.'],e:'か ist das gesprochene Fragezeichen.'}]},
{t:'Besitz und Verbindung mit の', jp:'AのB',
 intro:['<span class="j">A の B</span> heißt „B von A“ oder „As B“. Das Hauptwort steht immer hinten, die Bestimmung vorne.',
        'の verbindet auch Herkunft, Thema oder Zugehörigkeit: <span class="j">日本語の本</span> ist ein Buch auf/über Japanisch, <span class="j">大学の先生</span> ein Universitätsdozent.',
        'Ist das Hauptwort klar, kann es entfallen: <span class="j">私のです</span> – „Es ist meins.“'],
 pat:[['A の B','B von A']],
 ex:[['私[わたし]の 本[ほん]','mein Buch'],['先生[せんせい]の 車[くるま]','das Auto des Lehrers'],['日本語[にほんご]の 本[ほん]','ein Buch auf Japanisch'],['東京[とうきょう]の 大学[だいがく]','eine Universität in Tokio'],['これは 私[わたし]のです。','Das ist meins.']],
 q:[{q:'友達[ともだち]の 犬[いぬ]',jp:1,o:['der Hund meines Freundes','der Freund meines Hundes','Freund und Hund','mein Freund ist ein Hund'],e:'Das Hauptwort steht hinten: 犬 (Hund).'},
    {q:'母[はは]の 車[くるま]は 新[あたら]しいです。',jp:1,o:['Das Auto meiner Mutter ist neu.','Meine Mutter kauft ein neues Auto.','Meine Mutter ist neu im Auto.','Das neue Auto gehört nicht meiner Mutter.'],e:'母の車 = das Auto der Mutter.'},
    {q:'In „A の B“: Welches Wort ist das Hauptwort?',o:['B','A','beide gleich','keins von beiden'],e:'Im Japanischen steht das Bestimmte immer am Ende.'}]},
{t:'Zeigewörter: こ・そ・あ・ど', jp:'これ・それ・あれ・どれ',
 intro:['<b>こ</b> = nah beim Sprecher, <b>そ</b> = nah beim Zuhörer, <b>あ</b> = weit weg von beiden, <b>ど</b> = Fragewort.',
        'これ/それ/あれ stehen allein. この/その/あの stehen direkt vor einem Nomen. ここ/そこ/あそこ bezeichnen Orte.'],
 tbl:[['','こ','そ','あ','ど'],['Ding (allein)','これ','それ','あれ','どれ'],['+ Nomen','この','その','あの','どの'],['Ort','ここ','そこ','あそこ','どこ']],
 pat:[['この + Nomen','dieses …']],
 ex:[['これは 何[なん]ですか。','Was ist das (hier)?'],['この 本[ほん]は 高[たか]いです。','Dieses Buch ist teuer.'],['あの 人[ひと]は 誰[だれ]ですか。','Wer ist die Person dort drüben?'],['駅[えき]は あそこです。','Der Bahnhof ist dort drüben.'],['どの 傘[かさ]が あなたのですか。','Welcher Schirm ist deiner?']],
 q:[{q:'その 鞄[かばん]',jp:1,o:['die Tasche da (bei dir)','diese Tasche (bei mir)','die Tasche dort drüben','welche Tasche?'],e:'そ = beim Zuhörer.'},
    {q:'あそこ',jp:1,o:['dort drüben','hier','da (bei dir)','wo?'],e:'あ = weit weg, -そこ = Ort.'},
    {q:'Welches Wort steht direkt vor einem Nomen?',o:['この','これ','ここ','こう'],e:'この本, その人, あの店 …'}]},
{t:'Objekt mit を und die ます-Form', jp:'〜を〜ます',
 intro:['Das Verb steht im Japanischen immer am <b>Satzende</b>.',
        '<span class="j">を</span> (gesprochen <b>o</b>) markiert das direkte Objekt – das, was gegessen, gelesen, gekauft wird.',
        'Die <b>ます-Form</b> ist die höfliche Form des Verbs. Sie gilt für Gegenwart und Zukunft; das Japanische trennt die beiden nicht.'],
 tbl:[['Wörterbuch','ます-Form','Bedeutung'],['食べる','食べます','essen'],['飲む','飲みます','trinken'],['行く','行きます','gehen'],['する','します','machen'],['来る','来ます','kommen']],
 pat:[['[Objekt] を [Verb]ます','(ich) [tue] [Objekt]']],
 ex:[['パンを 食[た]べます。','Ich esse Brot.'],['水[みず]を 飲[の]みます。','Ich trinke Wasser.'],['明日[あした] 映画[えいが]を 見[み]ます。','Morgen sehe ich einen Film.'],['日本語[にほんご]を 勉強[べんきょう]します。','Ich lerne Japanisch.']],
 q:[{q:'本[ほん]を 読[よ]みます。',jp:1,o:['Ich lese ein Buch.','Ich kaufe ein Buch.','Ich schreibe ein Buch.','Das Buch ist gut.'],e:'読む = lesen.'},
    {q:'明日[あした] 魚[さかな]を 買[か]います。',jp:1,o:['Morgen kaufe ich Fisch.','Gestern habe ich Fisch gekauft.','Morgen esse ich Fisch.','Ich mag keinen Fisch.'],e:'明日 = morgen, 買う = kaufen.'},
    {q:'Was markiert を?',o:['das direkte Objekt','den Ort','die Zeit','das Thema'],e:'を zeigt, worauf sich die Handlung richtet.'}]},
{t:'Zeit, Ort, Richtung: に・へ・で・と', jp:'に・へ・で・と',
 intro:['<span class="j">に</span>: Zeitpunkt (<span class="j">七時に</span>) und Ziel (<span class="j">学校に行きます</span>).',
        '<span class="j">へ</span> (gesprochen <b>e</b>): Richtung – fast wie に beim Ziel.',
        '<span class="j">で</span>: Ort, an dem etwas <i>getan</i> wird (<span class="j">図書館で勉強します</span>), und Mittel (<span class="j">電車で</span>, <span class="j">日本語で</span>).',
        '<span class="j">と</span>: „mit“ einer Person (<span class="j">友達と</span>).'],
 pat:[['[Zeit] に','um / am …'],['[Ort] で [Handlung]','an … tun'],['[Mittel] で','mit, per …']],
 ex:[['七時[しちじ]に 起[お]きます。','Ich stehe um sieben auf.'],['東京[とうきょう]へ 行[い]きます。','Ich fahre nach Tokio.'],['図書館[としょかん]で 本[ほん]を 読[よ]みます。','Ich lese in der Bibliothek.'],['バスで 学校[がっこう]に 行[い]きます。','Ich fahre mit dem Bus zur Schule.'],['友達[ともだち]と 映画[えいが]を 見[み]ます。','Ich sehe mit einem Freund einen Film.']],
 q:[{q:'レストランで 晩[ばん]ご飯[はん]を 食[た]べます。',jp:1,o:['Ich esse im Restaurant zu Abend.','Ich gehe ins Restaurant.','Das Restaurant ist teuer.','Ich koche zu Abend.'],e:'で = Ort der Handlung.'},
    {q:'電車[でんしゃ]で 行[い]きます。',jp:1,o:['Ich fahre mit dem Zug.','Ich gehe zum Zug.','Ich warte auf den Zug.','Der Zug fährt.'],e:'で = Mittel.'},
    {q:'三時[さんじ]に 会[あ]いましょう。 – Was bedeutet に hier?',o:['Zeitpunkt','Ort der Handlung','Mittel','Objekt'],e:'三時に = um drei Uhr.'}]},
{t:'Verneinung und Vergangenheit', jp:'ません・ました・ませんでした',
 intro:['Die ます-Form hat vier Grundformen: bejaht/verneint × Gegenwart/Vergangenheit.',
        '<span class="j">〜ましょう</span> heißt „Lass uns …“, <span class="j">〜ませんか</span> ist eine höfliche Einladung: „Wollen wir nicht …?“'],
 tbl:[['','Gegenwart','Vergangenheit'],['Verb +','食べます','食べました'],['Verb –','食べません','食べませんでした'],['です +','です','でした'],['です –','じゃありません','じゃありませんでした']],
 pat:[['〜ましょう','Lass uns …'],['〜ませんか','Wollen wir …?']],
 ex:[['昨日[きのう] 映画[えいが]を 見[み]ました。','Gestern habe ich einen Film gesehen.'],['肉[にく]を 食[た]べません。','Ich esse kein Fleisch.'],['宿題[しゅくだい]を しませんでした。','Ich habe die Hausaufgaben nicht gemacht.'],['昨日[きのう]は 雨[あめ]でした。','Gestern war Regen.'],['一緒[いっしょ]に 行[い]きませんか。','Wollen wir zusammen gehen?']],
 q:[{q:'コーヒーを 飲[の]みませんでした。',jp:1,o:['Ich habe keinen Kaffee getrunken.','Ich trinke keinen Kaffee.','Ich habe Kaffee getrunken.','Lass uns Kaffee trinken.'],e:'ませんでした = verneinte Vergangenheit.'},
    {q:'昨日[きのう] 友達[ともだち]に 会[あ]いました。',jp:1,o:['Gestern habe ich einen Freund getroffen.','Morgen treffe ich einen Freund.','Gestern habe ich niemanden getroffen.','Ich treffe gerade einen Freund.'],e:'ました = Vergangenheit.'},
    {q:'食[た]べましょう。',jp:1,o:['Lass uns essen.','Ich habe gegessen.','Ich esse nicht.','Iss bitte.'],e:'ましょう = Vorschlag.'}]},
{t:'い-Adjektive', jp:'高い・高くない・高かった',
 intro:['い-Adjektive enden auf い und stehen direkt vor dem Nomen: <span class="j">高い本</span> (ein teures Buch).',
        'Sie werden selbst gebeugt: い → <span class="j">くない</span> (nicht), い → <span class="j">かった</span> (war), い → <span class="j">くなかった</span> (war nicht). です wird nur für die Höflichkeit angehängt.',
        'Ausnahme: <span class="j">いい</span> (gut) wird mit よ gebeugt: よくない, よかった.'],
 tbl:[['','Gegenwart','Vergangenheit'],['bejaht','高いです','高かったです'],['verneint','高くないです','高くなかったです']],
 pat:[['い-Adj + Nomen','高い 本'],['い-Adj + です','高いです']],
 ex:[['大[おお]きい 家[いえ]','ein großes Haus'],['この 本[ほん]は 高[たか]いです。','Dieses Buch ist teuer.'],['今日[きょう]は 寒[さむ]くないです。','Heute ist es nicht kalt.'],['旅行[りょこう]は 楽[たの]しかったです。','Die Reise hat Spaß gemacht.'],['映画[えいが]は よくなかったです。','Der Film war nicht gut.']],
 q:[{q:'寒[さむ]くないです。',jp:1,o:['Es ist nicht kalt.','Es war kalt.','Es ist kalt.','Es war nicht kalt.'],e:'くない = Verneinung.'},
    {q:'美味[おい]しかったです。',jp:1,o:['Es war lecker.','Es ist lecker.','Es war nicht lecker.','Es ist nicht lecker.'],e:'かった = Vergangenheit.'},
    {q:'Wie lautet die Vergangenheit von いい?',o:['よかった','いかった','いいでした','よいでした'],e:'いい ist unregelmäßig und wird über よい gebeugt.'}]},
{t:'な-Adjektive', jp:'静かな町',
 intro:['な-Adjektive brauchen vor einem Nomen ein <span class="j">な</span>: <span class="j">静かな町</span> (eine ruhige Stadt).',
        'Am Satzende verhalten sie sich wie Nomen: <span class="j">静かです / 静かじゃありません / 静かでした</span>.',
        'Wichtige な-Adjektive: 好き, 元気, 有名, 便利, 静か – und <span class="j">きれい</span>, das zwar auf い endet, aber ein な-Adjektiv ist.'],
 pat:[['な-Adj + な + Nomen','静かな 町'],['な-Adj + です','静かです']],
 ex:[['静[しず]かな 町[まち]','eine ruhige Stadt'],['京都[きょうと]は 有名[ゆうめい]です。','Kyoto ist berühmt.'],['私[わたし]は 魚[さかな]が 好[す]きじゃありません。','Ich mag keinen Fisch.'],['部屋[へや]は きれいでした。','Das Zimmer war sauber.']],
 q:[{q:'便利[べんり]な 町[まち]',jp:1,o:['eine praktische Stadt','die Stadt ist praktisch','eine ruhige Stadt','eine berühmte Stadt'],e:'便利 = praktisch, な verbindet mit dem Nomen.'},
    {q:'元気[げんき]じゃありません。',jp:1,o:['(Mir) geht es nicht gut.','(Mir) geht es gut.','(Mir) ging es gut.','Wie geht es dir?'],e:'じゃありません verneint.'},
    {q:'きれい ist ein …',o:['な-Adjektiv','い-Adjektiv','Verb','Nomen ohne Adjektivfunktion'],e:'Man sagt きれいな花, nicht きれい花.'}]},
{t:'Existenz: あります・います', jp:'〜に〜があります',
 intro:['<span class="j">あります</span> für Dinge und Pflanzen, <span class="j">います</span> für Menschen und Tiere.',
        'Muster: <span class="j">[Ort] に [Ding] が あります</span> – „An [Ort] gibt es [Ding].“',
        'あります bedeutet auch „haben“: <span class="j">時間があります</span> – „Ich habe Zeit.“ Verneint: ありません / いません.'],
 pat:[['[Ort] に [Ding] が あります','An [Ort] gibt es [Ding].'],['[Ort] に [Lebewesen] が います','An [Ort] ist [Lebewesen].']],
 ex:[['机[つくえ]の 上[うえ]に 本[ほん]が あります。','Auf dem Tisch liegt ein Buch.'],['公園[こうえん]に 子供[こども]が います。','Im Park sind Kinder.'],['時間[じかん]が ありません。','Ich habe keine Zeit.'],['猫[ねこ]は どこに いますか。','Wo ist die Katze?']],
 q:[{q:'部屋[へや]に 犬[いぬ]が います。',jp:1,o:['Im Zimmer ist ein Hund.','Der Hund hat ein Zimmer.','Im Zimmer ist kein Hund.','Der Hund geht ins Zimmer.'],e:'います für Tiere.'},
    {q:'Warum sagt man 先生がいます und nicht 先生があります?',o:['Weil der Lehrer ein Mensch ist.','Weil es höflicher ist.','Weil es Vergangenheit ist.','Beides ist gleich richtig.'],e:'Lebewesen → います.'},
    {q:'お金[かね]が ありません。',jp:1,o:['Ich habe kein Geld.','Ich habe Geld.','Wo ist das Geld?','Das Geld ist hier.'],e:'ありません = nicht vorhanden / nicht haben.'}]},
{t:'Die Partikel が', jp:'〜が好きです',
 intro:['<span class="j">が</span> markiert das Subjekt, oft wenn es neue oder betonte Information ist – zum Beispiel nach Fragewörtern: <span class="j">誰が来ましたか</span>.',
        'Bei <span class="j">好き</span>, <span class="j">上手</span>, <span class="j">分かる</span> und <span class="j">ある / いる</span> steht das, was gemocht, gekonnt oder verstanden wird, mit が.',
        'Faustregel: は stellt ein Thema vor („was X betrifft“), が legt den Fokus auf genau dieses Element.'],
 pat:[['A は B が 好きです','A mag B.']],
 ex:[['私[わたし]は 音楽[おんがく]が 好[す]きです。','Ich mag Musik.'],['日本語[にほんご]が 分[わ]かりますか。','Verstehst du Japanisch?'],['誰[だれ]が 来[き]ましたか。','Wer ist gekommen?'],['田中[たなか]さんが 来[き]ました。','Tanaka ist gekommen.'],['母[はは]は 料理[りょうり]が 上手[じょうず]です。','Meine Mutter kocht gut.']],
 q:[{q:'兄[あに]は 野球[やきゅう]が 好[す]きです。',jp:1,o:['Mein älterer Bruder mag Baseball.','Baseball mag meinen Bruder.','Mein Bruder spielt kein Baseball.','Ich mag Baseball mehr als mein Bruder.'],e:'A は B が好き = A mag B.'},
    {q:'誰[だれ]が 行[い]きますか。',jp:1,o:['Wer geht?','Wohin gehst du?','Gehst du?','Wann gehst du?'],e:'Nach Fragewörtern steht が.'},
    {q:'Mit welcher Partikel steht das, was man versteht (分かる)?',o:['が','を','に','で'],e:'日本語が分かります.'}]},
{t:'Die て-Form', jp:'〜てください・〜ています',
 intro:['Die て-Form verbindet Verben mit weiteren Ausdrücken. Für den Anfang sind zwei Muster wichtig:',
        '<span class="j">〜てください</span> – „Bitte tu …“ und <span class="j">〜ています</span> – „gerade tun“ oder ein andauernder Zustand (<span class="j">住んでいます</span> = wohnt, <span class="j">知っています</span> = weiß/kennt).',
        'Bildung: る-Verben ersetzen る durch て. Bei う-Verben hängt es von der Endung ab (siehe Tabelle). Unregelmäßig: する → して, 来る → 来て, 行く → 行って.'],
 tbl:[['Endung','Beispiel','て-Form'],['る (る-Verb)','食べる','食べて'],['う・つ・る','買う・待つ・帰る','買って・待って・帰って'],['む・ぶ・ぬ','飲む・遊ぶ','飲んで・遊んで'],['く / ぐ','書く / 泳ぐ','書いて / 泳いで'],['す','話す','話して']],
 pat:[['〜て ください','Bitte …'],['〜て います','gerade … / Zustand']],
 ex:[['ちょっと 待[ま]って ください。','Warte bitte kurz.'],['ゆっくり 話[はな]して ください。','Sprich bitte langsam.'],['今[いま] 雨[あめ]が 降[ふ]って います。','Es regnet gerade.'],['東京[とうきょう]に 住[す]んで います。','Ich wohne in Tokio.'],['猫[ねこ]が 寝[ね]て います。','Die Katze schläft.']],
 q:[{q:'見[み]て ください。',jp:1,o:['Schau bitte.','Ich schaue gerade.','Ich habe geschaut.','Ich schaue nicht.'],e:'てください = Bitte.'},
    {q:'本[ほん]を 読[よ]んで います。',jp:1,o:['Ich lese gerade ein Buch.','Lies bitte ein Buch.','Ich habe ein Buch gelesen.','Ich lese kein Buch.'],e:'ています = Verlauf.'},
    {q:'Wie lautet die て-Form von 飲む?',o:['飲んで','飲みて','飲って','飲いて'],e:'む → んで.'}]},
{t:'Die einfache Form', jp:'食べる・食べない・食べた',
 intro:['In Manga, Romanen, Liedern und unter Freunden steht statt der ます-Form die <b>einfache Form</b>. Zum Lesen und Hören musst du sie erkennen.',
        'Verneinung: る-Verben る → ない. う-Verben: Endung u → a + ない (<span class="j">書く → 書かない</span>, aber <span class="j">買う → 買わない</span>).',
        'Vergangenheit: wie die て-Form, nur mit た/だ (<span class="j">飲んで → 飲んだ</span>). です wird zu <span class="j">だ</span>.'],
 tbl:[['höflich','einfach','Bedeutung'],['食べます','食べる','esse'],['食べません','食べない','esse nicht'],['食べました','食べた','aß'],['行きません','行かない','gehe nicht'],['しました','した','tat'],['です / でした','だ / だった','ist / war']],
 pat:[['〜ない','nicht …'],['〜た','… (Vergangenheit)']],
 ex:[['明日[あした] 行[い]く？','Gehst du morgen?'],['今日[きょう]は 暇[ひま]だ。','Heute habe ich frei.'],['もう 食[た]べた。','Ich habe schon gegessen.'],['雨[あめ]が 降[ふ]らない。','Es regnet nicht.'],['昨日[きのう]は 寒[さむ]かった。','Gestern war es kalt.']],
 q:[{q:'行[い]かない',jp:1,o:['(ich) gehe nicht','(ich) ging','(ich) gehe','lass uns gehen'],e:'〜ない = Verneinung.'},
    {q:'食[た]べた',jp:1,o:['(ich) habe gegessen','(ich) esse nicht','(ich) esse','iss!'],e:'〜た = Vergangenheit.'},
    {q:'Was ist die höfliche Form von 見た?',o:['見ました','見ます','見ません','見ましょう'],e:'た ↔ ました.'}]}
];

const TEXTS = [
{t:'私の一日', de:'Mein Tag', lv:1, s:[
 ['私[わたし]は シュミットです。','Ich heiße Schmidt.'],
 ['ドイツ人[じん]です。','Ich bin Deutsche(r).'],
 ['大学[だいがく]の 学生[がくせい]です。','Ich studiere an der Universität.'],
 ['毎朝[まいあさ] 七時[しちじ]に 起[お]きます。','Jeden Morgen stehe ich um sieben Uhr auf.'],
 ['朝[あさ]ご飯[はん]は パンと 卵[たまご]です。','Zum Frühstück gibt es Brot und Ei.'],
 ['八時[はちじ]に 電車[でんしゃ]で 大学[だいがく]へ 行[い]きます。','Um acht Uhr fahre ich mit dem Zug zur Uni.'],
 ['大学[だいがく]で 日本語[にほんご]を 勉強[べんきょう]します。','An der Uni lerne ich Japanisch.'],
 ['日本語[にほんご]は 難[むずか]しいですが、楽[たの]しいです。','Japanisch ist schwierig, aber es macht Spaß.'],
 ['夜[よる]は 家[いえ]で 音楽[おんがく]を 聞[き]きます。','Abends höre ich zu Hause Musik.'],
 ['十一時[じゅういちじ]に 寝[ね]ます。','Um elf Uhr gehe ich schlafen.']],
 q:[{q:'Wie kommt Schmidt zur Uni?',o:['Mit dem Zug','Mit dem Auto','Zu Fuß','Mit dem Bus']},
    {q:'Was isst Schmidt zum Frühstück?',o:['Brot und Ei','Reis und Fisch','Nichts','Obst']},
    {q:'Wann geht Schmidt schlafen?',o:['Um elf Uhr','Um sieben Uhr','Um acht Uhr','Um zehn Uhr']}]},
{t:'私の家族', de:'Meine Familie', lv:1, s:[
 ['私[わたし]の 家族[かぞく]は 四人[よにん]です。','Meine Familie hat vier Personen.'],
 ['父[ちち]と 母[はは]と 姉[あね]と 私[わたし]です。','Vater, Mutter, meine ältere Schwester und ich.'],
 ['父[ちち]は 会社員[かいしゃいん]です。','Mein Vater ist Angestellter.'],
 ['毎日[まいにち] とても 忙[いそが]しいです。','Er ist jeden Tag sehr beschäftigt.'],
 ['母[はは]は 料理[りょうり]が 上手[じょうず]です。','Meine Mutter kocht gut.'],
 ['姉[あね]は 東京[とうきょう]に 住[す]んで います。','Meine ältere Schwester wohnt in Tokio.'],
 ['姉[あね]は 日本語[にほんご]の 先生[せんせい]です。','Sie ist Japanischlehrerin.'],
 ['家[いえ]には 猫[ねこ]も います。','Bei uns gibt es auch eine Katze.'],
 ['猫[ねこ]の 名前[なまえ]は タマです。','Die Katze heißt Tama.']],
 q:[{q:'Wo wohnt die ältere Schwester?',o:['In Tokio','In Kyoto','In Osaka','Bei den Eltern']},
    {q:'Was ist der Vater von Beruf?',o:['Angestellter','Lehrer','Koch','Arzt']},
    {q:'Wie heißt die Katze?',o:['Tama','Pochi','Hana','Kuro']}]},
{t:'週末', de:'Das Wochenende', lv:2, s:[
 ['先週[せんしゅう]の 土曜日[どようび]、友達[ともだち]と 町[まち]へ 行[い]きました。','Letzten Samstag bin ich mit einem Freund in die Stadt gegangen.'],
 ['天気[てんき]は とても よかったです。','Das Wetter war sehr gut.'],
 ['まず、新[あたら]しい 店[みせ]で 本[ほん]を 買[か]いました。','Zuerst habe ich in einem neuen Laden ein Buch gekauft.'],
 ['それから、レストランで 昼[ひる]ご飯[はん]を 食[た]べました。','Danach haben wir in einem Restaurant zu Mittag gegessen.'],
 ['ラーメンは 少[すこ]し 辛[から]かったですが、美味[おい]しかったです。','Die Ramen waren etwas scharf, aber lecker.'],
 ['午後[ごご]は 映画[えいが]を 見[み]ました。','Am Nachmittag haben wir einen Film gesehen.'],
 ['映画[えいが]は あまり 面白[おもしろ]くなかったです。','Der Film war nicht besonders interessant.'],
 ['日曜日[にちようび]は 家[いえ]で 休[やす]みました。','Am Sonntag habe ich mich zu Hause ausgeruht.']],
 q:[{q:'Wie war das Wetter am Samstag?',o:['Sehr gut','Regnerisch','Kalt','Schlecht']},
    {q:'Wie war der Film?',o:['Nicht besonders interessant','Sehr lustig','Traurig','Zu lang']},
    {q:'Was hat die Person am Sonntag gemacht?',o:['Sich zu Hause ausgeruht','Gearbeitet','Eingekauft','Einen Film gesehen']}]},
{t:'雨の日', de:'Ein Regentag', lv:2, s:[
 ['今日[きょう]は 朝[あさ]から 雨[あめ]が 降[ふ]って います。','Heute regnet es seit dem Morgen.'],
 ['外[そと]は 寒[さむ]いです。','Draußen ist es kalt.'],
 ['私[わたし]は 傘[かさ]を 持[も]って いませんから、出[で]かけません。','Ich habe keinen Schirm, deshalb gehe ich nicht raus.'],
 ['部屋[へや]で 温[あたた]かい お茶[ちゃ]を 飲[の]みます。','Im Zimmer trinke ich warmen Tee.'],
 ['それから、日本[にほん]の 小説[しょうせつ]を 読[よ]みます。','Danach lese ich einen japanischen Roman.'],
 ['漢字[かんじ]が 多[おお]いですから、ゆっくり 読[よ]みます。','Weil es viele Kanji gibt, lese ich langsam.'],
 ['分[わ]からない 言葉[ことば]は 辞書[じしょ]で 調[しら]べます。','Wörter, die ich nicht verstehe, schlage ich im Wörterbuch nach.'],
 ['雨[あめ]の 日[ひ]も 好[す]きです。','Ich mag auch Regentage.']],
 q:[{q:'Warum geht die Person nicht raus?',o:['Sie hat keinen Schirm.','Sie ist krank.','Sie muss arbeiten.','Es ist zu heiß.']},
    {q:'Was trinkt sie?',o:['Warmen Tee','Kalten Kaffee','Wasser','Milch']},
    {q:'Was macht sie mit unbekannten Wörtern?',o:['Im Wörterbuch nachschlagen','Überspringen','Einen Freund fragen','Auswendig lernen']}]},
{t:'レストランで', de:'Im Restaurant', lv:2, s:[
 ['店員[てんいん]：いらっしゃいませ。何名様[なんめいさま]ですか。','Kellner: Willkommen! Wie viele Personen?'],
 ['客[きゃく]：二人[ふたり]です。','Gast: Zwei.'],
 ['店員[てんいん]：こちらへ どうぞ。','Kellner: Hier entlang, bitte.'],
 ['客[きゃく]：すみません、メニューを ください。','Gast: Entschuldigung, die Speisekarte bitte.'],
 ['客[きゃく]：この 天[てん]ぷらは 何[なん]ですか。','Gast: Was ist das für ein Tempura?'],
 ['店員[てんいん]：海老[えび]と 野菜[やさい]の 天[てん]ぷらです。','Kellner: Tempura aus Garnelen und Gemüse.'],
 ['客[きゃく]：じゃあ、それを 二[ふた]つと、お茶[ちゃ]を お願[ねが]いします。','Gast: Dann zweimal das und Tee, bitte.'],
 ['店員[てんいん]：かしこまりました。','Kellner: Sehr gern.']],
 q:[{q:'Wie viele Personen kommen ins Restaurant?',o:['Zwei','Eine','Drei','Vier']},
    {q:'Was ist im Tempura?',o:['Garnelen und Gemüse','Fisch und Reis','Fleisch','Nur Gemüse']},
    {q:'Was bestellt der Gast zu trinken?',o:['Tee','Bier','Wasser','Saft']}]},
{t:'日本への旅行', de:'Die Reise nach Japan', lv:3, note:'In der einfachen Form geschrieben – wie ein Tagebuch (siehe Grammatik-Lektion 13).', s:[
 ['来月[らいげつ]、初[はじ]めて 日本[にほん]へ 行[い]く。','Nächsten Monat fahre ich zum ersten Mal nach Japan.'],
 ['二週間[にしゅうかん] 旅行[りょこう]する 予定[よてい]だ。','Ich plane, zwei Wochen zu reisen.'],
 ['まず 東京[とうきょう]で 友達[ともだち]に 会[あ]う。','Zuerst treffe ich in Tokio einen Freund.'],
 ['友達[ともだち]は 去年[きょねん]から 東京[とうきょう]に 住[す]んで いる。','Er wohnt seit letztem Jahr in Tokio.'],
 ['それから 京都[きょうと]で 古[ふる]い お寺[てら]を 見[み]たい。','Danach möchte ich in Kyoto alte Tempel sehen.'],
 ['日本語[にほんご]は まだ 上手[じょうず]じゃない。','Mein Japanisch ist noch nicht gut.'],
 ['でも、毎日[まいにち] 単語[たんご]を 勉強[べんきょう]して いる。','Aber ich lerne jeden Tag Vokabeln.'],
 ['日本[にほん]で たくさん 話[はな]したい。','In Japan möchte ich viel sprechen.']],
 q:[{q:'Wie lange dauert die Reise?',o:['Zwei Wochen','Einen Monat','Eine Woche','Drei Tage']},
    {q:'Seit wann wohnt der Freund in Tokio?',o:['Seit letztem Jahr','Seit diesem Monat','Seit seiner Geburt','Seit zwei Wochen']},
    {q:'Was möchte die Person in Kyoto?',o:['Alte Tempel sehen','Einen Freund treffen','Japanisch studieren','Einkaufen']}]}
];
