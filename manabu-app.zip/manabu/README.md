# Manabu（学ぶ）

Japanisch-Lern-App für Anfänger mit Fokus auf **Input**: Lesen, Hören, Vokabelverständnis.

- **Wiederholen:** Karteikarten mit „Gewusst“ / „Nicht gewusst“. Gewusst → der Abstand bis zur nächsten Abfrage wächst (ca. 1 → 3 → 8 → 20 Tage …). Nicht gewusst → die Karte kommt nach wenigen Minuten wieder, der Abstand wird kürzer.
- **Starter-Deck** mit 160 Grundwörtern samt Beispielsätzen und Furigana, dazu **Import des Core-2k/6k-Decks** aus Anki.
- **13 Grammatik-Lektionen** von は／です bis zur einfachen Form, jeweils mit Verständnisfragen.
- **6 Lesetexte** in drei Stufen, mit Übersetzung pro Satz und Vorlesefunktion.
- **Hörtraining:** Wort oder Satz hören, Bedeutung wählen.
- Funktioniert **offline** und im hellen wie im dunklen Modus. Der Fortschritt bleibt auf dem Handy und lässt sich als Sicherungsdatei mitnehmen.

Aus demselben Code entstehen zwei Apps:

| Handy | Was du bekommst | Wie es aufs Handy kommt |
|---|---|---|
| **Android** | Echte App (.apk) | GitHub baut sie automatisch, du lädst sie unter „Releases“ herunter |
| **iPhone** | Web-App auf dem Home-Bildschirm (Vollbild, offline, eigenes Icon) | GitHub veröffentlicht sie über GitHub Pages, du fügst sie in Safari hinzu |

> Eine „echte“ iPhone-App aus dem App Store braucht einen Mac mit Xcode und für die dauerhafte Installation ein Apple-Entwicklerkonto (99 €/Jahr). Das Projekt enthält alles dafür (siehe ganz unten).

---

## 1. Projekt auf GitHub hochladen (einmalig, ca. 5 Minuten)

1. ZIP-Datei entpacken.
2. Auf github.com ein **neues Repository** anlegen: oben rechts **+** → **New repository**.
   - Name: z. B. `manabu`
   - **Public** wählen (GitHub Pages für die iPhone-Version ist nur bei öffentlichen Repositories kostenlos).
   - **Kein** Häkchen bei „Add a README“.
   - **Create repository** klicken.
3. Auf der neuen Seite auf **„uploading an existing file“** klicken.
4. **Den Inhalt** des entpackten Ordners `manabu` ins Browserfenster ziehen, also die Dateien und Ordner darin, nicht den Ordner selbst.
5. Unten **Commit changes** klicken.

**Wichtig – Ordner `.github` prüfen:** Nach dem Hochladen muss in der Dateiliste ein Ordner `.github` stehen. Auf dem Mac ist er im Finder oft versteckt und wird dann nicht mit hochgeladen. Falls er fehlt: Im Finder **Cmd + Shift + .** drücken (zeigt versteckte Dateien) und den Ordner `.github` nachträglich hochladen.

## 2. GitHub Pages einschalten (für das iPhone)

Im Repository: **Settings → Pages → Build and deployment → Source: „GitHub Actions“**.

Danach: Reiter **Actions** → **„Web-App veröffentlichen (iPhone)“** → **Run workflow**.

## 3. Apps holen

Im Reiter **Actions** siehst du beide Builds laufen. Sie dauern ca. 2 Minuten (Web) und 5–8 Minuten (Android).

**Android**
1. Auf dem Handy die Repository-Seite öffnen → rechts **Releases** → neueste Version → **manabu.apk** antippen.
2. Die heruntergeladene Datei öffnen. Beim ersten Mal fragt Android, ob der Browser Apps installieren darf. Das einmal erlauben.
3. Updates: neue APK genauso über die alte installieren. Der Fortschritt bleibt erhalten.

**iPhone**
1. In Safari `https://DEIN-NAME.github.io/manabu/` öffnen.
2. **Teilen**-Taste → **„Zum Home-Bildschirm“**.
3. Ab jetzt die App über das Icon starten. Sie läuft auch ohne Internet.

**Sprachausgabe:** Die App spricht mit der japanischen Stimme deines Geräts.
- Android: Einstellungen → „Sprachausgabe“ → Google-Sprachausgabe → Japanisch installieren.
- iPhone: Einstellungen → Bedienungshilfen → Gesprochene Inhalte → Stimmen → Japanisch.

## 4. Core-2k/6k-Deck laden

1. In Anki am Computer: Deck auswählen → **Datei → Exportieren** → Format **„Notizen als Klartext (.txt)“**.
2. Die .txt-Datei aufs Handy bringen (Mail, Google Drive, iCloud …).
3. In der App: **設 (Deck & Optionen) → „Datei auswählen“** → Spaltenzuordnung prüfen → **Importieren**.

Die App rät, welche Spalte Wort, Lesung, Bedeutung und Beispielsatz ist. Du kannst die Zuordnung ändern. Anki-Audiodateien werden nicht übernommen, weil die App selbst vorliest.

## 5. Handy wechseln

**Deck & Optionen → Sicherung erstellen** speichert den ganzen Fortschritt samt importiertem Deck als Datei. Auf dem neuen Handy lädst du sie mit **„Sicherung laden“**.

---

## Für später: App ändern oder selbst bauen

Der Code der App liegt in `www/`:
- `www/js/content.js`: Wortschatz, Grammatik-Lektionen, Lesetexte
- `www/js/app.js`: Logik (Wiederholungs-Algorithmus, Import, Hörtraining …)
- `www/css/app.css`: Gestaltung

Jede Änderung, die du auf GitHub hochlädst, baut automatisch eine neue APK und aktualisiert die Web-Version.

Lokal am Computer mit Node.js 22:

```bash
npm install
npm run serve          # App im Browser unter http://localhost:8080
npm run android:init   # Android-Projekt erzeugen (dann in Android Studio: npx cap open android)
npm run ios:init       # nur Mac: iOS-Projekt erzeugen (dann: npx cap open ios)
```

**Signatur:** `signing/manabu.keystore` sorgt dafür, dass sich Updates über die alte Version installieren lassen. Das Passwort ist `manabu-app`. Für den privaten Gebrauch reicht das. Für den Google Play Store würdest du einen eigenen Schlüssel erzeugen und als GitHub-Secret hinterlegen (`KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`).

**Echte iPhone-App:** Auf einem Mac mit Xcode `npm install && npm run ios:init && npx cap open ios` ausführen, in Xcode deine Apple-ID als Team wählen und auf dem angeschlossenen iPhone starten. Mit einer kostenlosen Apple-ID läuft die App 7 Tage, mit Entwicklerkonto lässt sie sich über TestFlight verteilen.

Schriften: Klee One und Hanken Grotesk (SIL Open Font License).
